# FM-DX Android Universal 0.90.0

- Adicionada tela TV BOX CONNECT.
- Descoberta local DNS-SD/mDNS de serviços Google Cast, Android TV Remote, AirPlay, HTTP e HTTPS.
- Identificação somente de serviços anunciados; sem varredura de portas, autenticação ou captura protegida.
- A captura/reprodução de áudio e vídeo será implementada em etapas posteriores, conforme API autorizada ou hardware compatível.
