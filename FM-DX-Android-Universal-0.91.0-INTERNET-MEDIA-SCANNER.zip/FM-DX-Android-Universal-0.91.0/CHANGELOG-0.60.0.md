# FM-DX Android Universal 0.60.0

## Guia inteligente de fontes autorizadas

- Nova área para cadastrar playlists HTTP/HTTPS fornecidas explicitamente pelo usuário.
- Metadados de organização: nome, país, categoria e formato.
- Busca textual e filtros por país e categoria.
- Seleção de fontes cadastradas e envio ao fluxo já existente de importação em lote (máximo de 10 URLs).
- Cadastro e seleção persistidos no `localStorage` do navegador; exclusão individual de fontes.
- Validação no cadastro para aceitar somente HTTP/HTTPS e rejeitar URLs com credenciais.

## Segurança e limitações

- O guia é pessoal e local; não é um diretório público nem um serviço de descoberta automática.
- Não há scraping de listas de terceiros, bypass de autenticação, DRM, paywall ou bloqueios de operadora.
- O usuário deve cadastrar apenas fontes cujo acesso e uso estejam autorizados.
- A importação continua usando as verificações de URL pública, limite de 10 playlists, limite de leitura e concorrência já existentes.

## Testes

- Testes Node.js existentes, verificação de sintaxe JavaScript da interface e integridade do ZIP.
- Não foi realizada compilação APK nem teste em hardware físico.
