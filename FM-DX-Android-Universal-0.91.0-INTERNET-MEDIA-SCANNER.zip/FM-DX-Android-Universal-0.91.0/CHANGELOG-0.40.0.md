# FM-DX Android Universal 0.40.0 — Cross-Device Cohort Analysis

## Novidades
- Novo `CrossDeviceCohortAnalyzer` organiza observações locais por família de plataforma identificada nos campos públicos do Android.
- Comparação apresenta quantidade de observações, modelos distintos, fingerprints, modelos de SoC expostos e resultados FM ainda não comprovados.
- Interpretação aponta quando há apenas uma observação, múltiplos modelos ou variações de SoC dentro do grupo.
- Relatório do Hardware Test Lab atualizado para 0.40.0.
- `versionName` atualizado para 0.40.0 e `versionCode` para 25.

## Privacidade e limites
- A análise usa somente o histórico local já armazenado no aplicativo; não envia dados para servidor e não combina relatórios de usuários diferentes.
- Agrupar por família SoC não demonstra que dois aparelhos compartilham tuner, cristal, driver, HAL ou suporte FM.
- Os resultados continuam observacionais. FM acessível exige teste funcional específico do modelo, variante e firmware.
- Nenhuma interface privada, root ou bypass de permissões é utilizado.

## Validação
- Verificação de sintaxe/estrutura do ZIP e inspeção dos arquivos alterados.
- A compilação Android não foi executada neste ambiente; validar com Android Studio, JDK 17 e Android SDK/Gradle compatíveis.
