# FM-DX Android Universal 0.89.0

## Satélite FTA e IPTV
- Adicionada área de cadastro local de transponders DVB-S, DVB-S2 e DVB-S2X, com frequência, polarização, symbol rate, modulação e estado FTA.
- O cadastro é armazenado no navegador/dispositivo e não representa sintonia RF.
- A leitura de playlists M3U agora apresenta `ftaStatus` somente quando o texto da própria lista indica FTA/aberto ou codificado; metadados ausentes permanecem como `não informado`.
- Mantidas importação M3U/M3U8, biblioteca unificada, scanner SDR e módulos existentes.

## Limitações
- A recepção/sintonia DVB-S/S2 requer hardware receptor compatível e integração específica ainda não implementada.
- A classificação FTA inferida de texto é indicativa, não uma verificação criptográfica do sinal.
