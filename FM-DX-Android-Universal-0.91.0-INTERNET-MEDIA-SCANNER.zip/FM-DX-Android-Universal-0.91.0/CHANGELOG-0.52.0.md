# FM-DX Android Universal 0.52.0 — Analisador MPEG-TS

## Evolução
- Adicionado parser de pacotes MPEG Transport Stream de 188 bytes.
- Extração de PID, indicador de erro de transporte, início de unidade de payload, prioridade, scrambling, adaptation-field-control e continuity counter.
- Estatísticas de sincronismo, erros, pacotes embaralhados, pacotes nulos e quantidade de PIDs.
- Criado contrato `TvTransportSource` para futura integração com backends USB específicos.
- Testes unitários com fluxos sintéticos.

## Limites
Esta versão não implementa sintonia, demodulação, driver USB universal, decodificação de vídeo/áudio ou reprodução ao vivo. O parser precisa receber bytes MPEG-TS de uma implementação real de driver/demodulador. A detecção de USB da versão 0.51.0 continua sendo apenas inventário e evidência.

## Validação
Verificação estrutural do ZIP e inspeção estática dos novos arquivos. Executar `./gradlew test` e `./gradlew assembleDebug` com JDK 17 e Android SDK 35 para validação completa.
