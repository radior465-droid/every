package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class IsdbtCaptionTimelineTest {
    private val nhk = byteArrayOf(0x1b, 0x28, 0x4a, 'N'.code.toByte(), 'H'.code.toByte(), 'K'.code.toByte())

    @Test fun addsDecodedTimedCaptionAndFindsActiveCue() {
        val timeline = IsdbtCaptionTimeline()
        val state = timeline.addTextBlock(1, 1_000, 3_000, nhk, "jpn")
        assertEquals("NHK", state.latestCue?.text)
        assertEquals(4_000L, state.latestCue?.endTimeMs)
        assertEquals(1L, timeline.activeAt(2_000)?.cueId)
        assertNull(timeline.activeAt(4_000))
    }

    @Test fun rejectsDuplicateIdsAndInvalidTiming() {
        val timeline = IsdbtCaptionTimeline()
        timeline.addTextBlock(1, 0, 1000, nhk)
        timeline.addTextBlock(1, 1000, 1000, nhk)
        timeline.addTextBlock(2, -1, 1000, nhk)
        assertEquals(1, timeline.snapshot().cues.size)
        assertEquals(2, timeline.snapshot().rejectedCount)
    }

    @Test fun boundsHistoryAndClearResetsState() {
        val timeline = IsdbtCaptionTimeline(maxCues = 2)
        timeline.addTextBlock(1, 0, 1000, nhk)
        timeline.addTextBlock(2, 1000, 1000, nhk)
        timeline.addTextBlock(3, 2000, 1000, nhk)
        assertEquals(listOf(2L, 3L), timeline.snapshot().cues.map { it.cueId })
        timeline.clear()
        assertTrue(timeline.snapshot().cues.isEmpty())
        assertEquals(0, timeline.snapshot().rejectedCount)
    }
}
