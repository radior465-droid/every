package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class TvUsbChipsetCatalogTest {
    @Test fun recognizesKnownRealtek2838Family() {
        val profile = TvUsbChipsetCatalog.identify(0x0bda, 0x2838)
        assertNotNull(profile)
        assertTrue(profile!!.chipset.contains("RTL2832U"))
        assertEquals(listOf(TvStandard.DVB_T), profile.standards)
    }

    @Test fun recognizesKnownRealtek2832Family() {
        assertNotNull(TvUsbChipsetCatalog.identify(0x0bda, 0x2832))
    }

    @Test fun unknownIdsDoNotGuessChipsetOrStandard() {
        assertNull(TvUsbChipsetCatalog.identify(0xffff, 0x1234))
        assertTrue(TvUsbChipsetCatalog.describe(0xffff, 0x1234).contains("não catalogado"))
    }

    @Test fun catalogDoesNotClaimAndroidDriverIsIntegrated() {
        assertTrue(TvUsbChipsetCatalog.all().all { it.driverStatus.contains("Sem driver") })
    }
}
