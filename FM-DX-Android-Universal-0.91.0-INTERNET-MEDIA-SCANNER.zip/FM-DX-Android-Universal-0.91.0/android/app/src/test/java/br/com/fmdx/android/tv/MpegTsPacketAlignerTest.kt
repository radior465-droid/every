package br.com.fmdx.android.tv

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MpegTsPacketAlignerTest {
    @Test fun alignsPacketsAcrossChunkBoundaries() {
        val aligner = MpegTsPacketAligner()
        val packet = ByteArray(188).also { it[0] = 0x47; it[3] = 0x10 }
        val first = aligner.push(byteArrayOf(0x00, 0x01) + packet.copyOfRange(0, 90))
        assertTrue(first.isEmpty())
        val second = aligner.push(packet.copyOfRange(90, 188) + packet)
        assertEquals(376, second.size)
        assertEquals(0x47, second[0].toInt() and 0xff)
        assertEquals(0x47, second[188].toInt() and 0xff)
    }

    @Test fun ignoresNoiseBeforeSyncByte() {
        val aligner = MpegTsPacketAligner()
        val packet = ByteArray(188).also { it[0] = 0x47; it[3] = 0x10 }
        val result = aligner.push(byteArrayOf(9, 8, 7) + packet)
        assertEquals(188, result.size)
        assertEquals(0x47, result[0].toInt() and 0xff)
    }
}
