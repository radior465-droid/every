package br.com.fmdx.android.fm.probe

import java.io.File

/**
 * Inspeção estritamente observacional de caminhos conhecidos relacionados a rádio.
 * Não faz varredura recursiva, não lê conteúdo de nós e não tenta abrir/controlar tuners.
 */
object RadioNodeEvidenceScanner {
    data class NodeEvidence(
        val path: String,
        val exists: Boolean,
        val readable: Boolean,
        val writable: Boolean,
        val directory: Boolean
    ) {
        fun asText(): String = buildString {
            append(path)
            append(if (exists) " — presente" else " — ausente")
            if (exists) {
                append(if (directory) " (diretório)" else " (arquivo/nó)")
                append(if (readable) ", leitura permitida" else ", leitura não permitida")
                append(if (writable) ", escrita permitida" else ", escrita não permitida")
            }
        }
    }

    val candidatePaths: List<String> = listOf(
        "/dev/radio0",
        "/dev/radio1",
        "/dev/fm",
        "/dev/fm0",
        "/sys/class/radio",
        "/sys/class/video4linux",
        "/sys/module/radio_iris",
        "/sys/module/wcnss_core",
        "/vendor/lib/hw",
        "/vendor/lib64/hw",
        "/vendor/lib",
        "/vendor/lib64",
        "/system/lib/hw",
        "/system/lib64/hw"
    )

    fun inspect(paths: List<String> = candidatePaths): List<NodeEvidence> = paths.distinct().map { path ->
        val file = File(path)
        val exists = runCatching { file.exists() }.getOrDefault(false)
        NodeEvidence(
            path = path,
            exists = exists,
            readable = exists && runCatching { file.canRead() }.getOrDefault(false),
            writable = exists && runCatching { file.canWrite() }.getOrDefault(false),
            directory = exists && runCatching { file.isDirectory }.getOrDefault(false)
        )
    }

    fun summary(nodes: List<NodeEvidence>): String {
        val present = nodes.count { it.exists }
        val accessible = nodes.count { it.exists && it.readable }
        return "$present/${nodes.size} caminhos presentes; $accessible legíveis pelo aplicativo. Isso não comprova tuner FM funcional."
    }
}
