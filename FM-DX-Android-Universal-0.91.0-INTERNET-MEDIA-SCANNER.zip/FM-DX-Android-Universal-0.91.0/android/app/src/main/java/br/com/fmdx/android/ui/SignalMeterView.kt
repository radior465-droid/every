package br.com.fmdx.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Indicador visual local. Não representa potência RF real sem backend comprovado. */
class SignalMeterView(context: Context) : View(context) {
    var level: Int = 0
        set(value) { field = value.coerceIn(0, 100); invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bars = 10
        val gap = width * 0.02f
        val barW = (width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val h = height * (0.25f + 0.075f * i)
            val left = i * (barW + gap)
            val top = height - h
            val threshold = (i + 1) * 10
            paint.color = if (level >= threshold) Color.rgb(53, 182, 232) else Color.rgb(42, 64, 80)
            canvas.drawRoundRect(left, top, left + barW, height.toFloat(), 8f, 8f, paint)
        }
    }
}
