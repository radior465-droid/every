package br.com.fmdx.android.fm.database

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class CompatibilityRecord(
    val fingerprint: String,
    val manufacturer: String,
    val model: String,
    val platform: String,
    val recommendedMode: String,
    val evidenceSummary: String,
    val lastTestResult: String,
    val confidence: Int,
    val updatedAt: Long = System.currentTimeMillis()
)

/** Local, evidence-based compatibility cache. It stores observations only and
 * never upgrades diagnostic evidence into proof of native tuner control. */
class CompatibilityDatabase(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_compatibility", Context.MODE_PRIVATE)
    private val key = "records"

    fun all(): List<CompatibilityRecord> = runCatching {
        val array = JSONArray(prefs.getString(key, "[]"))
        (0 until array.length()).map { i -> decode(array.getJSONObject(i)) }
    }.getOrDefault(emptyList())

    fun find(fingerprint: String): CompatibilityRecord? = all().firstOrNull { it.fingerprint == fingerprint }

    fun upsert(record: CompatibilityRecord) {
        val records = all().filterNot { it.fingerprint == record.fingerprint } + record
        val array = JSONArray()
        records.forEach { array.put(encode(it)) }
        prefs.edit().putString(key, array.toString()).apply()
    }

    fun clear() = prefs.edit().remove(key).apply()

    private fun encode(r: CompatibilityRecord) = JSONObject().apply {
        put("fingerprint", r.fingerprint); put("manufacturer", r.manufacturer)
        put("model", r.model); put("platform", r.platform)
        put("recommendedMode", r.recommendedMode); put("evidenceSummary", r.evidenceSummary)
        put("lastTestResult", r.lastTestResult); put("confidence", r.confidence)
        put("updatedAt", r.updatedAt)
    }

    private fun decode(o: JSONObject) = CompatibilityRecord(
        o.optString("fingerprint"), o.optString("manufacturer"), o.optString("model"),
        o.optString("platform"), o.optString("recommendedMode"), o.optString("evidenceSummary"),
        o.optString("lastTestResult"), o.optInt("confidence"), o.optLong("updatedAt")
    )
}
