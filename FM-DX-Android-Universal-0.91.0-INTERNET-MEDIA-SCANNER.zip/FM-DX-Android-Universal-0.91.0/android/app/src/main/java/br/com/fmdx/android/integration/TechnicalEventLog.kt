package br.com.fmdx.android.integration

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TechnicalEvent(val timestamp: Long, val level: String, val source: String, val message: String)

class TechnicalEventLog(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_technical_log", Context.MODE_PRIVATE)
    private val key = "events"

    fun add(level: String, source: String, message: String) {
        val events = readMutable()
        events.put(JSONObject().put("timestamp", System.currentTimeMillis()).put("level", level).put("source", source).put("message", message))
        val capped = JSONArray()
        val start = maxOf(0, events.length() - 200)
        for (i in start until events.length()) capped.put(events.get(i))
        prefs.edit().putString(key, capped.toString()).apply()
    }

    fun exportText(): String = buildString {
        for (event in read()) append(event.timestamp).append(" [").append(event.level).append("] ").append(event.source).append(": ").append(event.message).append('\n')
    }

    fun read(): List<TechnicalEvent> {
        val array = readMutable()
        return (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            TechnicalEvent(o.optLong("timestamp"), o.optString("level", "INFO"), o.optString("source"), o.optString("message"))
        }
    }

    private fun readMutable(): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
}
