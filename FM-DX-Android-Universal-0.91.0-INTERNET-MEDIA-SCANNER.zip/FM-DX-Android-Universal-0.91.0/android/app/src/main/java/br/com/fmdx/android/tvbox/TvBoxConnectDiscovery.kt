package br.com.fmdx.android.tvbox

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Serviço anunciado em rede local. LOCATION é a descrição UPnP, não uma URL de canal. */
data class TvBoxService(
    val name: String,
    val serviceType: String,
    val host: String?,
    val port: Int,
    val locationUrl: String? = null,
    val discovery: String = "DNS-SD"
)

/**
 * Descoberta local somente de leitura via DNS-SD e SSDP/UPnP.
 * Não varre portas/IPs, não tenta login e não extrai conteúdo protegido.
 */
class TvBoxConnectDiscovery(context: Context, private val onUpdate: (List<TvBoxService>) -> Unit) {
    private val app = context.applicationContext
    private val manager = app.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val main = Handler(Looper.getMainLooper())
    private val found = ConcurrentHashMap<String, TvBoxService>()
    private val listeners = mutableMapOf<String, NsdManager.DiscoveryListener>()
    private val running = AtomicBoolean(false)
    @Volatile private var ssdpSocket: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    private val serviceTypes = listOf(
        "_googlecast._tcp.", "_androidtvremote2._tcp.", "_airplay._tcp.",
        "_http._tcp.", "_https._tcp.", "_upnp._tcp.", "_dlna._tcp."
    )

    @Synchronized fun start() {
        stop()
        found.clear()
        running.set(true)
        try {
            multicastLock = wifi.createMulticastLock("fmdx-tvbox-discovery").apply { setReferenceCounted(false); acquire() }
        } catch (_: SecurityException) { }
        publish()
        serviceTypes.forEach { type ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(serviceType: String) = Unit
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { stopListener(serviceType, this) }
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { stopListener(serviceType, this) }
                override fun onDiscoveryStopped(serviceType: String) = Unit
                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    if (serviceInfo.serviceName.isNullOrBlank()) return
                    try {
                        manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = Unit
                            override fun onServiceResolved(info: NsdServiceInfo) {
                                val host = info.host?.hostAddress
                                val item = TvBoxService(info.serviceName, info.serviceType ?: type, host, info.port)
                                found["${item.serviceType}|${item.name}|${item.host}|${item.port}"] = item
                                publish()
                            }
                        })
                    } catch (_: IllegalArgumentException) { }
                }
                override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                    found.entries.removeIf { it.value.name == serviceInfo.serviceName && it.value.discovery == "DNS-SD" }
                    publish()
                }
            }
            listeners[type] = listener
            try { manager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener) }
            catch (_: RuntimeException) { listeners.remove(type) }
        }
        thread(name = "fmdx-ssdp-discovery", isDaemon = true) { discoverSsdp() }
    }

    private fun discoverSsdp() {
        val socket = try { DatagramSocket().apply { soTimeout = 500; ssdpSocket = this } } catch (_: Exception) { return }
        try {
            val request = ("M-SEARCH * HTTP/1.1\r\n" +
                "HOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\n" +
                "MX: 2\r\n" +
                "ST: ssdp:all\r\n\r\n").toByteArray(Charsets.US_ASCII)
            socket.send(DatagramPacket(request, request.size, InetAddress.getByName("239.255.255.250"), 1900))
            val deadline = System.currentTimeMillis() + 4500
            val buffer = ByteArray(8192)
            while (running.get() && System.currentTimeMillis() < deadline) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    socket.receive(packet)
                    val response = String(packet.data, packet.offset, packet.length, Charsets.ISO_8859_1)
                    val headers = response.lineSequence().drop(1).mapNotNull { line ->
                        val split = line.indexOf(':'); if (split <= 0) null else line.substring(0, split).trim().lowercase() to line.substring(split + 1).trim()
                    }.toMap()
                    val location = headers["location"] ?: continue
                    val uri = try { URL(location) } catch (_: Exception) { continue }
                    if (uri.protocol !in listOf("http", "https") || uri.userInfo != null) continue
                    val st = headers["st"] ?: headers["nt"] ?: "UPnP device"
                    val name = headers["server"]?.take(120) ?: uri.host
                    val item = TvBoxService(name, st, packet.address.hostAddress, uri.port.takeIf { it > 0 } ?: if (uri.protocol == "https") 443 else 80, uri.toString(), "SSDP/UPnP")
                    found["SSDP|${uri.host}|${uri.path}|$st"] = item
                    publish()
                } catch (_: java.net.SocketTimeoutException) { }
                catch (_: Exception) { if (running.get()) continue else break }
            }
        } catch (_: Exception) { }
        finally { if (ssdpSocket === socket) ssdpSocket = null; socket.close() }
    }

    @Synchronized fun stop() {
        running.set(false)
        ssdpSocket?.close(); ssdpSocket = null
        listeners.toMap().forEach { (type, listener) -> stopListener(type, listener) }
        listeners.clear()
        try { multicastLock?.let { if (it.isHeld) it.release() } } catch (_: RuntimeException) { }
        multicastLock = null
    }

    @Synchronized private fun stopListener(type: String, listener: NsdManager.DiscoveryListener) {
        try { manager.stopServiceDiscovery(listener) } catch (_: RuntimeException) { }
        if (listeners[type] === listener) listeners.remove(type)
    }

    private fun publish() {
        val snapshot = found.values.sortedWith(compareBy<TvBoxService> { it.name.lowercase() }.thenBy { it.serviceType })
        main.post { onUpdate(snapshot) }
    }
}
