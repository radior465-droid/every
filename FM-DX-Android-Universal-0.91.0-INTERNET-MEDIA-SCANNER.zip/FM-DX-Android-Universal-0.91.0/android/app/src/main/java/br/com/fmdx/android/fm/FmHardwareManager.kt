package br.com.fmdx.android.fm

import android.content.Context
import android.os.Build
import br.com.fmdx.android.fm.detector.UniversalHardwareDetector
import br.com.fmdx.android.fm.core.VirtualRadioCore
import br.com.fmdx.android.fm.core.AdaptiveRadioDecisionEngine
import br.com.fmdx.android.fm.core.CompatibilityLearningEngine
import br.com.fmdx.android.fm.core.CompatibilityReportEngine
import br.com.fmdx.android.fm.database.CompatibilityDatabase
import br.com.fmdx.android.fm.hybrid.HybridRadioEngine
import br.com.fmdx.android.fm.signature.SignatureGenerator
import br.com.fmdx.android.fm.lab.HardwareTestLab
import br.com.fmdx.android.fm.lab.HardwareTestRunner
import br.com.fmdx.android.fm.lab.CompatibilityTimeline
import br.com.fmdx.android.fm.matrix.DeviceEvidenceMatrix
import br.com.fmdx.android.fm.probe.FmDriverProbe

/** Seleciona somente pelo perfil de chipset; fabricante sozinho não libera um backend. */
class FmHardwareManager(private val context: Context) {
    private val usbDiscovery = UsbReceiverDiscovery(context.applicationContext)
    private val samsungDiagnostics by lazy { SamsungExynosDiagnostics(context.applicationContext) }
    private val universalDiagnostics by lazy { UniversalFmDiagnostics(context.applicationContext) }
    private val profile by lazy { DeviceProfileDetector.detect() }
    private val universalHardwareDetector by lazy { UniversalHardwareDetector(context.applicationContext) }
    private val virtualRadioCore by lazy { VirtualRadioCore() }
    private val compatibilityDatabase by lazy { CompatibilityDatabase(context.applicationContext) }
    private val compatibilityLearning by lazy { CompatibilityLearningEngine(compatibilityDatabase) }
    private val controller: FmRadioController by lazy {
        when (profile.backendId) {
            "qualcomm" -> QualcommFmController()
            "mediatek" -> MediaTekFmController()
            "samsung_exynos" -> SamsungFmController()
            else -> UnsupportedFmController()
        }
    }

    fun controller(): FmRadioController = controller
    fun samsungDiagnosticReport(): String = samsungDiagnostics.run().asText()
    fun universalDiagnosticReport(): String = universalDiagnostics.run().asText()
    fun fmDriverProbeReport(): String = FmDriverProbe(context.applicationContext, controller).run().asText()



    fun adaptiveRadioReport(): String {
        val hardwareProfile = universalHardwareDetector.detect()
        val decision = AdaptiveRadioDecisionEngine.evaluate(hardwareProfile)
        return decision.asText(hardwareProfile)
    }

    fun hybridRadioReport(): String {
        val hardwareProfile = universalHardwareDetector.detect()
        return HybridRadioEngine.evaluate(hardwareProfile).asText()
    }

    fun compatibilityDeviceReport(): String {
        val hardwareProfile = universalHardwareDetector.detect()
        val (text, record) = CompatibilityReportEngine.current(hardwareProfile)
        compatibilityLearning.remember(record)
        return text + "\n" + compatibilityLearning.confidenceHint(record.fingerprint)
    }

    fun compatibilityHistoryReport(): String = CompatibilityReportEngine.history(compatibilityDatabase.all())

    fun clearCompatibilityHistory() = compatibilityDatabase.clear()

    fun runHardwareLab(): String = HardwareTestLab(context.applicationContext).runAndSave()
    fun hardwareLabHistory(): String = HardwareTestLab(context.applicationContext).history()
    fun clearHardwareLabHistory() = HardwareTestLab(context.applicationContext).clear()

    fun evidenceMatrixReport(): String = DeviceEvidenceMatrix.evaluate(context.applicationContext).asText()

    fun runStructuredTests(): String = HardwareTestRunner(context.applicationContext).runAndSave()
    fun structuredTestHistory(): String = HardwareTestRunner(context.applicationContext).history()
    fun clearStructuredTestHistory() = HardwareTestRunner(context.applicationContext).clear()

    fun compatibilityTimelineReport(): String {
        val profile = universalHardwareDetector.detect()
        val signature = SignatureGenerator.generate(profile).key
        return CompatibilityTimeline(context.applicationContext).report(signature)
    }

    fun advancedHardwareReport(): String {
        val hardwareProfile = universalHardwareDetector.detect()
        val decision = virtualRadioCore.evaluate(hardwareProfile)
        val signature = SignatureGenerator.generate(hardwareProfile)
        return buildString {
            append("FM-DX Android — Hardware Profile 0.22.0\n\n")
            append("Plataforma: ${hardwareProfile.platform}\n")
            append("Confiança: ${hardwareProfile.confidenceScore}%\n")
            append("Modo recomendado: ${decision.mode}\n")
            append("Decisão: ${decision.explanation}\n")
            append("Assinatura: ${signature.key}\n\n")
            append("EVIDÊNCIAS\n")
            if (hardwareProfile.evidence.isEmpty()) append("Nenhuma evidência coletada.\n")
            else hardwareProfile.evidence.forEach { append("• ${it.type}: ${it.value} [${it.status}, ${it.confidence}%]\n") }
            append("\nObservação: assinatura e evidências não concedem acesso ao hardware nem contornam bloqueios do sistema.")
        }
    }

    fun report(): String = buildString {
        append("FM-DX Android — Compatibilidade 0.22.0\n\n")
        append("Fabricante: ${Build.MANUFACTURER.ifBlank { "Desconhecido" }}\n")
        append("Modelo: ${Build.MODEL.ifBlank { "Desconhecido" }}\n")
        append("Hardware: ${Build.HARDWARE}\nBoard: ${Build.BOARD}\nSoC fabricante: ${profile.socManufacturer.ifBlank { "não informado" }}\nSoC modelo: ${profile.socModel.ifBlank { "não informado" }}\nAndroid: ${Build.VERSION.RELEASE}\n\n")
        append("PLATAFORMA DETECTADA\n")
        append("${profile.summary()}\n")
        profile.evidence.forEach { append("• $it\n") }
        append("\nBACKEND\n")
        append("Selecionado: ${controller.backendName}\nModo: diagnóstico seguro\n")
        append(if (controller.isSupported()) "Controle real do tuner: disponível" else "Controle real do tuner: ainda não validado para este aparelho")
        append("\n\nRECEPTORES USB\n")
        val devices = usbDiscovery.describeAttachedDevices()
        if (devices.isEmpty()) append("Nenhum dispositivo USB detectado.") else devices.forEach { append("• $it\n") }
        append("\nA detecção USB não confirma compatibilidade FM/SDR: é necessário protocolo e driver acessíveis ao Android.")
    }
}
