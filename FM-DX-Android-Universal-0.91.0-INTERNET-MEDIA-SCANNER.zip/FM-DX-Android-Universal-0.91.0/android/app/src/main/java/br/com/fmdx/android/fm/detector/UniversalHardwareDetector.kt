package br.com.fmdx.android.fm.detector

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import br.com.fmdx.android.fm.DeviceProfileDetector
import br.com.fmdx.android.fm.evidence.AccessLevel
import br.com.fmdx.android.fm.evidence.Evidence
import br.com.fmdx.android.fm.evidence.EvidenceStatus
import br.com.fmdx.android.fm.profile.HardwareProfile

class UniversalHardwareDetector(private val context: Context) {
    fun detect(): HardwareProfile {
        val device = DeviceProfileDetector.detect()
        val evidence = mutableListOf<Evidence>()
        evidence += Evidence("PLATFORM", "Build", device.platform,
            if (device.backendId == "unsupported") EvidenceStatus.UNKNOWN else EvidenceStatus.PROBABLE,
            when (device.confidence) { "alta" -> 85; "média" -> 65; else -> 35 })

        val features = context.packageManager.systemAvailableFeatures.mapNotNull { it.name }
            .filter { it.contains("fm", true) || it.contains("radio", true) }
        features.forEach { evidence += Evidence("SYSTEM_FEATURE", "PackageManager", it,
            EvidenceStatus.OBSERVED, 80, AccessLevel.PUBLIC) }

        val packages = try {
            val flags = if (Build.VERSION.SDK_INT >= 33) PackageManager.ApplicationInfoFlags.of(0) else null
            val apps = if (flags != null) context.packageManager.getInstalledApplications(flags)
                       else @Suppress("DEPRECATION") context.packageManager.getInstalledApplications(0)
            apps.map { it.packageName }.filter { it.contains("fm", true) || it.contains("radio", true) }.take(20)
        } catch (_: Exception) { emptyList() }
        packages.forEach { evidence += Evidence("RADIO_PACKAGE", "PackageManager", it,
            EvidenceStatus.OBSERVED, 45, AccessLevel.UNKNOWN) }

        val score = evidence.map { it.confidence }.average().toInt().coerceIn(0, 100)
        val mode = when {
            evidence.any { it.type == "SYSTEM_FEATURE" && it.access == AccessLevel.PUBLIC } -> "ADAPTER_MODE"
            device.backendId != "unsupported" -> "DIAGNOSTIC_MODE"
            else -> "DIAGNOSTIC_MODE"
        }
        return HardwareProfile(device.manufacturer, device.model, device.platform,
            "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})", evidence, score, mode)
    }
}
