package br.com.fmdx.android.integration

enum class CapabilityState {
    AVAILABLE,
    DETECTED,
    EXPERIMENTAL,
    DRIVER_REQUIRED,
    UNSUPPORTED,
    UNKNOWN
}

data class CapabilityStatus(
    val id: String,
    val title: String,
    val state: CapabilityState,
    val detail: String,
    val updatedAt: Long = System.currentTimeMillis()
)
