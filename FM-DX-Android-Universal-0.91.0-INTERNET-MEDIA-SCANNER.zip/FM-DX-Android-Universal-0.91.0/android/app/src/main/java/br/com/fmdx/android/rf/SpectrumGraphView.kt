package br.com.fmdx.android.rf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Gráfico de espectro para dados fornecidos pelo motor; não captura RF por conta própria. */
class SpectrumGraphView(context: Context) : View(context) {
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(55, 83, 105); strokeWidth = 1f }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(53, 210, 190); strokeWidth = 2.6f; style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(183, 201, 216); textSize = 27f }
    private var levels: List<Double> = emptyList()

    fun submitSpectrum(values: List<Double>) {
        levels = values.toList()
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = 54f; val right = width - 18f; val top = 18f; val bottom = height - 38f
        if (right <= left || bottom <= top) return
        canvas.drawColor(Color.rgb(12, 30, 46))
        for (step in 0..4) {
            val y = top + (bottom - top) * step / 4f
            canvas.drawLine(left, y, right, y, gridPaint)
            canvas.drawText("${-20 - step * 20} dB", 3f, y + 8f, textPaint)
        }
        for (step in 0..4) {
            val x = left + (right - left) * step / 4f
            canvas.drawLine(x, top, x, bottom, gridPaint)
        }
        if (levels.size < 2) {
            canvas.drawText("Aguardando amostras I/Q...", left + 12f, (top + bottom) / 2f, textPaint)
            return
        }
        val path = Path()
        val count = levels.size
        levels.forEachIndexed { index, raw ->
            val db = max(-100.0, min(0.0, raw))
            val x = left + (right - left) * index / (count - 1).toFloat()
            val y = bottom - ((db + 100.0) / 100.0 * (bottom - top)).toFloat()
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, linePaint)
        canvas.drawText("-Fs/2", left, height - 7f, textPaint)
        canvas.drawText("0", (left + right) / 2f - 8f, height - 7f, textPaint)
        canvas.drawText("+Fs/2", right - 78f, height - 7f, textPaint)
    }
}
