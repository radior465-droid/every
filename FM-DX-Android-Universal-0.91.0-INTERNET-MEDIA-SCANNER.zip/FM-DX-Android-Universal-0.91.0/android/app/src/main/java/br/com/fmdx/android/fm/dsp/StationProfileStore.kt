package br.com.fmdx.android.fm.dsp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class StationProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_station_profiles", Context.MODE_PRIVATE)

    fun save(profile: StationProfile) {
        val all = load().filterNot { it.frequencyKhz == profile.frequencyKhz }.toMutableList()
        all.add(profile)
        val array = JSONArray()
        all.sortedBy { it.frequencyKhz }.forEach {
            array.put(JSONObject().apply {
                put("frequencyKhz", it.frequencyKhz); put("label", it.label)
                put("source", it.source); put("confidence", it.confidence); put("notes", it.notes)
            })
        }
        prefs.edit().putString("profiles", array.toString()).apply()
    }

    fun load(): List<StationProfile> {
        val array = JSONArray(prefs.getString("profiles", "[]"))
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            StationProfile(o.optInt("frequencyKhz"), o.optString("label"), o.optString("source"), o.optInt("confidence"), o.optString("notes"))
        }
    }
}
