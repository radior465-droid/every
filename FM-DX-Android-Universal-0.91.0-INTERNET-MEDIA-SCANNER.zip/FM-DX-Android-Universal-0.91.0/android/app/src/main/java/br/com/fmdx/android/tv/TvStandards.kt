package br.com.fmdx.android.tv

/** Padrões de TV digital que o projeto pode identificar como alvo; não implica driver disponível. */
enum class TvStandard(val displayName: String) {
    ISDB_T("ISDB-T / SBTVD (Brasil)"), DVB_T("DVB-T"), DVB_T2("DVB-T2"), ATSC("ATSC"), ATSC_3("ATSC 3.0"), DTMB("DTMB"), UNKNOWN("Padrão não identificado")
}

data class TvUsbEvidence(
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val interfaceCount: Int,
    val hasPermission: Boolean,
    val likelyTuner: Boolean,
    val notes: String,
    val interfaces: List<TvUsbInterfaceEvidence> = emptyList()
)

data class TvUsbInterfaceEvidence(val number: Int, val interfaceClass: Int, val subclass: Int, val protocol: Int) {
    val classLabel: String get() = when (interfaceClass) {
        0x01 -> "Áudio"; 0x02 -> "Comunicação"; 0x03 -> "HID"; 0x08 -> "Armazenamento";
        0x0e -> "Vídeo"; 0xff -> "Proprietária"; else -> "Classe 0x%02X".format(interfaceClass)
    }
}

data class TvCompatibilityProfile(
    val preferredStandard: TvStandard,
    val supportedTargets: List<TvStandard>,
    val usbHostRequired: Boolean = true,
    val needsVendorDriverOrUserspaceDemodulator: Boolean = true,
    val liveReceptionAvailable: Boolean = false
)

object TvCompatibility {
    /** O Brasil usa ISDB-T. O perfil é uma preferência regional, não detecção do padrão do dongle. */
    fun profile(countryCode: String): TvCompatibilityProfile {
        val preferred = if (countryCode.equals("BR", ignoreCase = true)) TvStandard.ISDB_T else TvStandard.UNKNOWN
        return TvCompatibilityProfile(preferred, listOf(TvStandard.ISDB_T, TvStandard.DVB_T, TvStandard.DVB_T2, TvStandard.ATSC, TvStandard.ATSC_3, TvStandard.DTMB))
    }

    /** Heurística conservadora: interfaces USB de vídeo/classe vendor são apenas indícios. */
    fun classify(interfaceClasses: List<Int>): Pair<Boolean, String> {
        val video = interfaceClasses.any { it == 0x0e }
        val vendor = interfaceClasses.any { it == 0xff }
        return when {
            video -> true to "Interface USB de vídeo encontrada; confirmar chipset e protocolo do sintonizador."
            vendor -> true to "Interface proprietária encontrada; pode ser tuner, mas requer identificação VID/PID e driver."
            else -> false to "Nenhuma classe USB típica de vídeo/proprietária; isso não exclui um tuner." 
        }
    }
}
