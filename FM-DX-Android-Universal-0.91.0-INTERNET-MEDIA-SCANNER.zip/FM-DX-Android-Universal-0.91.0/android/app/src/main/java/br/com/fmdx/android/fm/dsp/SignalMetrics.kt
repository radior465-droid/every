package br.com.fmdx.android.fm.dsp

data class SignalMetrics(
    val rms: Double,
    val peak: Double,
    val zeroCrossingRate: Double,
    val estimatedLevelDb: Double,
    val classification: String
)
