package br.com.fmdx.android.events

import java.util.concurrent.CopyOnWriteArrayList

sealed class MediaEvent {
    data class UsbChanged(val connected: Boolean, val description: String = "") : MediaEvent()
    data class PlayerStateChanged(val state: PlayerState, val detail: String = "") : MediaEvent()
    data class FmStatusChanged(val status: String, val detail: String = "") : MediaEvent()
    data class SourceClassified(val sourceType: String, val detail: String = "") : MediaEvent()
}

enum class PlayerState { IDLE, PREPARING, PLAYING, PAUSED, ENDED, ERROR }

object MediaEventManager {
    private val listeners = CopyOnWriteArrayList<(MediaEvent) -> Unit>()
    fun subscribe(listener: (MediaEvent) -> Unit) { listeners += listener }
    fun unsubscribe(listener: (MediaEvent) -> Unit) { listeners -= listener }
    fun publish(event: MediaEvent) { listeners.forEach { it(event) } }
}
