package br.com.fmdx.android.tv

/** Matriz de interoperabilidade baseada em documentação pública; não indica teste local. */
enum class BackendEvidence { PUBLIC_HARDWARE_CONFIRMATION, PUBLIC_SUPPORT_NEEDS_TESTING, NOT_CONFIRMED }

data class IsdbtBackendProfile(
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val standard: String,
    val evidence: BackendEvidence,
    val backendProject: String,
    val notes: String
)

object IsdbtBackendPlan {
    const val OPENDTV_REPOSITORY = "https://github.com/jpdcs/OpenDTV"
    const val OPENDTV_LICENSE = "MIT"

    val profiles = listOf(
        IsdbtBackendProfile("ITE/Afatech IT9175 / Mygica PT275", 0x048d, 0x275a, "ISDB-T/SBTVD", BackendEvidence.PUBLIC_HARDWARE_CONFIRMATION, "OpenDTV", "Projeto upstream declara suporte confirmado ao PT275 em hardware; revisão exata da placa ainda pode variar."),
        IsdbtBackendProfile("ITE IT9308 / TV Plus GO", 0x048d, 0x9308, "ISDB-T", BackendEvidence.PUBLIC_SUPPORT_NEEDS_TESTING, "OpenDTV", "Upstream lista suporte, mas solicita testes adicionais; manter caminho separado do IT9175.")
    )

    /** Não habilita driver por conta própria: serve para selecionar e explicar uma trilha de integração. */
    fun find(vendorId: Int, productId: Int): IsdbtBackendProfile? =
        profiles.firstOrNull { it.vendorId == vendorId && it.productId == productId }
}
