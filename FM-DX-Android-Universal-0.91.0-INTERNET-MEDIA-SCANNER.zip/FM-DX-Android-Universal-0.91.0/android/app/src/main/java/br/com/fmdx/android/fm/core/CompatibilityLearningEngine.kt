package br.com.fmdx.android.fm.core

import br.com.fmdx.android.fm.database.CompatibilityDatabase
import br.com.fmdx.android.fm.database.CompatibilityRecord

/** Combines current observations with previous local tests without pretending
 * that a heuristic result is a hardware capability. */
class CompatibilityLearningEngine(private val database: CompatibilityDatabase) {
    fun remember(record: CompatibilityRecord) = database.upsert(record)
    fun previous(fingerprint: String): CompatibilityRecord? = database.find(fingerprint)

    fun confidenceHint(fingerprint: String): String {
        val previous = previous(fingerprint) ?: return "Sem histórico local para este dispositivo"
        return "Histórico local: ${previous.lastTestResult} (confiança ${previous.confidence}%)"
    }
}
