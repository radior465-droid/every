package br.com.fmdx.android.tv

/** MPEG-2 PSI CRC-32 (poly 0x04C11DB7, init 0xFFFFFFFF, no reflection/xor-out). */
object MpegPsiCrc32 {
    fun calculate(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): Long {
        require(offset >= 0 && length >= 0 && offset + length <= data.size)
        var crc = 0xFFFFFFFFL
        for (index in offset until offset + length) {
            crc = crc xor ((data[index].toLong() and 0xFF) shl 24)
            repeat(8) {
                crc = if ((crc and 0x80000000L) != 0L) ((crc shl 1) xor 0x04C11DB7L) and 0xFFFFFFFFL
                      else (crc shl 1) and 0xFFFFFFFFL
            }
        }
        return crc
    }

    /** A complete PSI section, including its four CRC bytes, has a zero remainder. */
    fun isValidSection(section: ByteArray): Boolean {
        if (section.size < 7) return false
        val sectionLength = ((section[1].toInt() and 0x0F) shl 8) or (section[2].toInt() and 0xFF)
        return section.size == 3 + sectionLength && calculate(section) == 0L
    }
}
