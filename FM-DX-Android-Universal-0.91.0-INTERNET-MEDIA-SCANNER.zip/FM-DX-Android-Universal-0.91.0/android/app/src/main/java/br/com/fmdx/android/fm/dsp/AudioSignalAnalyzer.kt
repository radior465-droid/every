package br.com.fmdx.android.fm.dsp

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Analisa amostras PCM já fornecidas por uma fonte autorizada.
 * Não captura nem contorna as restrições de áudio do Android.
 */
object AudioSignalAnalyzer {
    fun analyze(samples: ShortArray): SignalMetrics {
        if (samples.isEmpty()) return SignalMetrics(0.0, 0.0, 0.0, -120.0, "SEM AMOSTRAS")
        var sum = 0.0
        var peak = 0.0
        var crossings = 0
        var previous = samples[0].toInt()
        for (sample in samples) {
            val normalized = sample.toDouble() / Short.MAX_VALUE
            sum += normalized * normalized
            peak = maxOf(peak, abs(normalized))
            val current = sample.toInt()
            if ((previous < 0 && current >= 0) || (previous >= 0 && current < 0)) crossings++
            previous = current
        }
        val rms = sqrt(sum / samples.size)
        val db = if (rms <= 0.0) -120.0 else 20.0 * log10(rms).coerceAtLeast(-120.0)
        val zcr = crossings.toDouble() / samples.size
        val classification = when {
            rms < 0.003 -> "SILÊNCIO / SEM FONTE"
            peak > 0.98 && rms > 0.5 -> "SINAL MUITO FORTE / POSSÍVEL CLIPPING"
            rms > 0.05 -> "ÁUDIO ATIVO"
            else -> "SINAL FRACO"
        }
        return SignalMetrics(rms, peak, zcr, db, classification)
    }
}
