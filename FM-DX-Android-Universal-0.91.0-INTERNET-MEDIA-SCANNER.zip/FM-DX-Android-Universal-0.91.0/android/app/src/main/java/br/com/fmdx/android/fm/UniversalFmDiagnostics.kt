package br.com.fmdx.android.fm

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/** Diagnóstico universal e somente de leitura. Perfis não significam acesso garantido ao tuner. */
class UniversalFmDiagnostics(private val context: Context) {
    data class Result(val lines: List<String>) { fun asText() = lines.joinToString("\n") }

    fun run(): Result {
        val pm = context.packageManager
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val manufacturer = Build.MANUFACTURER.orEmpty()
        val brand = Build.BRAND.orEmpty()
        val model = Build.MODEL.orEmpty()
        val hardware = Build.HARDWARE.orEmpty()
        val board = Build.BOARD.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val text = "$manufacturer $brand $model $hardware $board $product".lowercase()

        val profile = when {
            manufacturer.equals("samsung", true) && (text.contains("exynos") || text.contains("s5e")) -> "Samsung / Exynos"
            manufacturer.equals("samsung", true) && (text.contains("qcom") || text.contains("sm") || text.contains("sdm")) -> "Samsung / Qualcomm (possível)"
            text.contains("qcom") || text.contains("sdm") || text.contains("snapdragon") -> "Qualcomm / Snapdragon"
            Regex("(^|[^a-z0-9])mt[0-9]{4}").containsMatchIn(text) || text.contains("mediatek") -> "MediaTek"
            manufacturer.equals("samsung", true) -> "Samsung / plataforma não identificada"
            else -> "Genérico / plataforma desconhecida"
        }

        val headset = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val features = pm.systemAvailableFeatures.mapNotNull { it.name }
            .filter { it.contains("fm", true) || it.contains("radio", true) }

        val apps = try {
            val list = if (Build.VERSION.SDK_INT >= 33) pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            else @Suppress("DEPRECATION") pm.getInstalledApplications(0)
            list.mapNotNull {
                val label = try { pm.getApplicationLabel(it).toString() } catch (_: Exception) { "" }
                if (it.packageName.contains("fm", true) || it.packageName.contains("radio", true) || label.contains("fm", true) || label.contains("radio", true)) it.packageName else null
            }.distinct().sorted()
        } catch (_: Exception) { emptyList() }

        val confidence = when {
            features.isNotEmpty() -> "🟢 Interface/recurso público relacionado encontrado"
            apps.isNotEmpty() -> "🟡 Componente de rádio encontrado; acesso por app comum não confirmado"
            profile != "Genérico / plataforma desconhecida" -> "🟠 Plataforma reconhecida; API pública de FM não confirmada"
            else -> "🔴 Nenhuma evidência pública de controle FM encontrada"
        }

        return Result(buildList {
            add("FM-DX Android — Diagnóstico Universal")
            add("")
            add("DISPOSITIVO")
            add("Fabricante: ${manufacturer.ifBlank { "Desconhecido" }}")
            add("Marca: ${brand.ifBlank { "Desconhecida" }}")
            add("Modelo: ${model.ifBlank { "Desconhecido" }}")
            add("Hardware: ${hardware.ifBlank { "Desconhecido" }}")
            add("Board: ${board.ifBlank { "Desconhecido" }}")
            add("Produto: ${product.ifBlank { "Desconhecido" }}")
            add("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            add("")
            add("PERFIL AUTOMÁTICO")
            add("Perfil selecionado: $profile")
            add("")
            add("ANTENA / ÁUDIO")
            add(if (headset) "Fone/headset detectado: ✓" else "Fone/headset detectado: não")
            add("Observação: detectar fone não confirma tuner FM.")
            add("")
            add("EVIDÊNCIAS PÚBLICAS")
            if (features.isEmpty()) add("Recursos FM/Radio declarados: nenhum") else features.forEach { add("• Recurso: $it") }
            if (apps.isEmpty()) add("Pacotes relacionados: nenhum encontrado") else apps.take(20).forEach { add("• Pacote: $it") }
            add("")
            add("COMPATIBILIDADE")
            add(confidence)
            add("Perfis servem para diagnóstico e seleção de backend; não simulam suporte nem usam APIs privadas.")
        })
    }
}
