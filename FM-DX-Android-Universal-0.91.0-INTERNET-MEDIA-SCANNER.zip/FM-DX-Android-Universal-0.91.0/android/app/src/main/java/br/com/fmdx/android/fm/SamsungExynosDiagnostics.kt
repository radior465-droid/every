package br.com.fmdx.android.fm

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/** Diagnóstico somente de leitura: não tenta acessar APIs privadas nem drivers protegidos. */
class SamsungExynosDiagnostics(private val context: Context) {
    data class Result(
        val lines: List<String>
    ) {
        fun asText(): String = lines.joinToString("\n")
    }

    fun run(): Result {
        val pm = context.packageManager
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val isSamsung = Build.MANUFACTURER.equals("samsung", true)
        val hardware = Build.HARDWARE.orEmpty()
        val board = Build.BOARD.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val exynosLike = hardware.contains("exynos", true) || hardware.contains("s5e", true) ||
                board.contains("exynos", true) || board.contains("s5e", true)

        val featureNames = pm.systemAvailableFeatures.mapNotNull { it.name }
        val fmFeatures = featureNames.filter { it.contains("fm", true) || it.contains("radio", true) }

        val headsetOutputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }

        val installedApps = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
        } catch (_: Exception) { emptyList() }

        val radioPackages = try {
            installedApps
                .filter {
                    val p = it.packageName
                    val label = pm.getApplicationLabel(it).toString()
                    p.contains("fm", true) || p.contains("radio", true) ||
                            label.contains("fm", true) || label.contains("radio", true)
                }
                .map { it.packageName }
                .sorted()
        } catch (_: Exception) { emptyList() }

        val lines = mutableListOf<String>()
        lines += "FM-DX Android — Diagnóstico Samsung/Exynos"
        lines += ""
        lines += "MODELO"
        lines += "Modelo: ${Build.MODEL.ifBlank { "Desconhecido" }}"
        lines += "Fabricante: ${Build.MANUFACTURER.ifBlank { "Desconhecido" }} ${if (isSamsung) "✓" else "✗"}"
        lines += "Hardware: ${hardware.ifBlank { "Desconhecido" }}"
        lines += "Board: ${board.ifBlank { "Desconhecido" }}"
        lines += "Produto: ${product.ifBlank { "Desconhecido" }}"
        lines += "Perfil Exynos/S5E: ${if (exynosLike) "detectado ✓" else "não confirmado ?"}"
        lines += "Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
        lines += ""
        lines += "ANTENA / ÁUDIO"
        lines += if (headsetOutputs.isNotEmpty()) "Fone/headset com fio detectado: ✓" else "Fone/headset com fio detectado: não"
        lines += "Observação: detectar um fone não confirma acesso ao tuner FM."
        lines += ""
        lines += "RECURSOS DECLARADOS PELO SISTEMA"
        lines += if (fmFeatures.isEmpty()) "Nenhum recurso FM/Radio público encontrado." else fmFeatures.joinToString("\n") { "• $it" }
        lines += ""
        lines += "PACOTES RELACIONADOS"
        lines += if (radioPackages.isEmpty()) "Nenhum pacote com nome/rótulo relacionado a FM/Radio encontrado." else radioPackages.take(20).joinToString("\n") { "• $it" }
        if (radioPackages.size > 20) lines += "• ... (${radioPackages.size} encontrados)"
        lines += ""
        lines += "CONTROLE REAL DO TUNER"
        lines += "API pública validada: não confirmada"
        lines += "Backend privado/Samsung: não utilizado pelo diagnóstico"
        lines += "Resultado: este relatório não afirma suporte até existir uma interface legítima e acessível ao app."

        return Result(lines)
    }
}
