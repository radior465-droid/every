package br.com.fmdx.android.fm

class UnsupportedFmController : FmRadioController {
    override val backendName = "Nenhum driver FM público disponível"
    override fun isSupported() = false
    override fun start() = false
    override fun stop() = Unit
    override fun tune(frequencyKhz: Int) = false
    override fun getFrequency(): Int? = null
    override fun seekUp(): Int? = null
    override fun seekDown(): Int? = null
}
