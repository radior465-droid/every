package br.com.fmdx.android.video

data class VideoSource(val url: String, val label: String = "Fonte de vídeo", val type: Type = Type.AUTO) {
    enum class Type { AUTO, MP4, HLS, DASH, WEB }
}
