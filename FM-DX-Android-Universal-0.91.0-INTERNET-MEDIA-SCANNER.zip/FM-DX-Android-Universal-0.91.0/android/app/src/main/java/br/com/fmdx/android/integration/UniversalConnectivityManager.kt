package br.com.fmdx.android.integration

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.hardware.usb.UsbManager
import android.os.Build
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager

/** Read-only inventory of communication paths. It never enables radios or changes network settings. */
object UniversalConnectivityManager {
    data class Item(val name: String, val state: String, val detail: String)

    fun snapshot(context: Context): List<Item> {
        val pm = context.packageManager
        val result = mutableListOf<Item>()
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val connected = caps != null
        val transports = mutableListOf<String>()
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) transports += "Wi-Fi"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) transports += "rede móvel"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) transports += "Ethernet"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) == true) transports += "Bluetooth PAN"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) transports += "VPN"
        result += Item("Conexão ativa", if (connected) "CONECTADO" else "SEM REDE", transports.joinToString().ifBlank { "Nenhum transporte identificado" })
        result += Item("Wi-Fi", if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) "CONECTADO" else if (pm.hasSystemFeature(PackageManager.FEATURE_WIFI)) "DISPONÍVEL / NÃO É A REDE ATIVA" else "NÃO DETECTADO", "Estado baseado no transporte de rede ativo; o app não liga/desliga o Wi-Fi.")
        result += Item("Rede móvel", if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) "CONECTADO" else if (pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) "HARDWARE PRESENTE / NÃO É A REDE ATIVA" else "NÃO DETECTADO", "4G/5G depende do modem, plano, cobertura e configuração do Android.")
        result += Item("Bluetooth", if (pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)) "HARDWARE PRESENTE" else "NÃO DETECTADO", "Pareamento e leitura de dispositivos exigem permissões e consentimento adicionais.")
        val usb = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val usbDevices = usb.deviceList.values
        result += Item("USB / OTG", if (pm.hasSystemFeature(PackageManager.FEATURE_USB_HOST)) "HOST SUPORTADO" else "HOST NÃO CONFIRMADO", if (usbDevices.isEmpty()) "Nenhum periférico USB conectado" else "${usbDevices.size} dispositivo(s): " + usbDevices.joinToString { "${it.vendorId.toString(16)}:${it.productId.toString(16)}" })
        result += Item("Ethernet", if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) "CONECTADO" else "NÃO ATIVO", "Pode depender de adaptador USB-C/OTG compatível.")
        result += Item("NFC", if (pm.hasSystemFeature(PackageManager.FEATURE_NFC)) "HARDWARE PRESENTE" else "NÃO DETECTADO", "Adequado para identificação/troca curta de dados, não para áudio contínuo.")
        result += Item("Internet validada", if (caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true) "SIM" else "NÃO CONFIRMADA", "O Android informa se a rede ativa tem acesso validado à internet.")
        return result
    }
}
