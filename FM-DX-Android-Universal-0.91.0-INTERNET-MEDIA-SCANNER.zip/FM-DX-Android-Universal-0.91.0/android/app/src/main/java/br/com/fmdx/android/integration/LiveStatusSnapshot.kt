package br.com.fmdx.android.integration

data class LiveStatusSnapshot(
    val fm: String = "UNKNOWN",
    val video: String = "AVAILABLE",
    val usb: String = "UNKNOWN",
    val diagnostics: String = "READY",
    val intelligence: String = "UNKNOWN"
)
