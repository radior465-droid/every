package br.com.fmdx.android.tv

/** Referências ISDB-T sem VID/PID USB confirmado. Não usar para identificar um dongle por si só. */
data class IsdbtHardwareReference(
    val name: String,
    val role: String,
    val evidenceLevel: String,
    val usbIds: List<String> = emptyList(),
    val notes: String,
    val sourceUrl: String
)

object IsdbtHardwareReferences {
    val all: List<IsdbtHardwareReference> = listOf(
        IsdbtHardwareReference(
            name = "DiBcom DIB8076",
            role = "Demodulador ISDB-TB / SBTVD reportado em receptor PixelView PV-D231U",
            evidenceLevel = "Modelo comercial documentado; VID/PID e driver Android não confirmados",
            notes = "A ficha do produto informa DIB8076 e ISDB-TB Full-Seg. Não inferir ID USB a partir do modelo comercial.",
            sourceUrl = "https://www.kabum.com.br/produto/6784/receptor-de-tv-digital-pixelview-playtv-usb-2-0-sbtvd-full-seg-pv-d231u-rn-f"
        ),
        IsdbtHardwareReference(
            name = "MaxLinear MxL683",
            role = "SoC tuner-demodulador ISDB-T / SBTVD-T",
            evidenceLevel = "Documentação oficial do fabricante; dongle USB e VID/PID não especificados na referência",
            notes = "Fabricante declara conformidade com especificações brasileiras SBTVD-T. É evidência de chipset compatível com padrão, não de driver Android/USB pronto.",
            sourceUrl = "https://www.maxlinear.com/news/press-releases/2014/maxlinear%E2%80%99s-new-low-cost-usb-dongle-reference-desi"
        ),
        IsdbtHardwareReference(
            name = "HikariSoft ISDB-TB1 / ISDB-TB2",
            role = "Receptores compactos ISDB-T para Brasil/Japão",
            evidenceLevel = "Produto documentado pelo fabricante; disponibilidade/driver Android não confirmados",
            notes = "A página do fabricante descreve modelos ISDB-T para Brasil/Japão e interface USB em produtos da família. Não há VID/PID publicado na referência consultada.",
            sourceUrl = "https://www.hikarisoft.com/products.en.html"
        )
    )
}
