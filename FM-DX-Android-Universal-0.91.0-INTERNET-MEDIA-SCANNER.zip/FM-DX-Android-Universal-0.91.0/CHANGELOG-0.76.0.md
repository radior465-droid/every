# FM-DX Android Universal 0.76.0 — Plano de integração ISDB-T OpenDTV

- Adicionado catálogo de compatibilidade para IT9175/PT275 (`048D:275A`) e IT9308 (`048D:9308`) com níveis distintos de evidência pública.
- Adicionada camada de seleção de perfil por VID/PID, sem abrir USB nem executar comandos.
- Documentada avaliação de integração com OpenDTV, etapas de portabilidade, validação e cuidados de licença MIT/GPL-3.0.
- Nenhum código upstream foi copiado nesta versão; nenhum driver funcional ou recepção ao vivo é reivindicado.
- Android atualizado para `versionCode 53` e `versionName 0.76.0`.
