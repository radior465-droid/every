# FM-DX Android Universal 0.70.0 — Media3 e formatos adaptativos

## Novidades
- Substituição do `MediaPlayer` pelo AndroidX Media3 ExoPlayer no serviço nativo.
- Dependências Media3 para reprodução progressiva, HLS e MPEG-DASH.
- Mantida a fila nativa, os controles da notificação e o avanço automático ao fim do item.
- Tratamento de erros e estados de buffering/pronto/reprodução/pausa.

## Compatibilidade e limites
- HLS e DASH de áudio/radio são aceitos pelo serviço nativo e dependem de URL/manifesto acessível e codecs suportados pelo dispositivo.
- Streams protegidos por DRM, autenticação proprietária ou formatos não suportados não são desbloqueados.
- A reprodução HLS/DASH deve ser identificada como rádio/áudio e iniciada por URL de mídia compatível; playlists M3U/M3U8 que sejam apenas listas de canais precisam ter um item selecionado. Vídeo/TV continua no player de primeiro plano.
- Dependências AndroidX Media3 1.5.1 são resolvidas pelo Gradle via Google Maven/Maven Central.
- Não foi possível executar build Android/APK ou validar reprodução real em hardware neste ambiente.
