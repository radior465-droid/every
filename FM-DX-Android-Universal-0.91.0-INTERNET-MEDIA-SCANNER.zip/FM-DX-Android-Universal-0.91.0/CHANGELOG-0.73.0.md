# 0.73.0 — Inteligência de compatibilidade ISDB-T/SBTVD

## Novidades
- Adicionados perfis USB ISDB-T documentados: ITE/Afatech IT9175 (048d:275a), ITE IT9308 (048d:9308) e famílias Siano RIO (3275:0080, 187f:0600, 187f:0302).
- Criado catálogo separado de referências ISDB-T sem VID/PID confirmado: DiBcom DIB8076, MaxLinear MxL683 e HikariSoft ISDB-TB1/TB2.
- Cada perfil explicita evidência, limitações e situação de driver; IDs não provam revisão de placa, tuner RF, firmware ou compatibilidade Android.

## Evidências técnicas consultadas
- OpenDTV (Android ISDB-T; lista 048d:275a e 048d:9308): https://github.com/jpdcs/OpenDTV
- siano-userland (IDs Siano RIO, firmware necessário e uso Android via Termux): https://github.com/Khronos31/siano-userland
- MaxLinear MxL683 (declaração do fabricante sobre SBTVD-T): https://www.maxlinear.com/news/press-releases/2014/maxlinear%E2%80%99s-new-low-cost-usb-dongle-reference-desi
- HikariSoft ISDB-TB1/TB2: https://www.hikarisoft.com/products.en.html
- PixelView PV-D231U / DIB8076: https://www.kabum.com.br/produto/6784/receptor-de-tv-digital-pixelview-playtv-usb-2-0-sbtvd-full-seg-pv-d231u-rn-f

## Limitações
- Nenhum driver de recepção ao vivo foi integrado nesta versão.
- O suporte Siano citado para Android é via Termux/userspace e depende do firmware `isdbt_rio.inp`; isso não equivale a suporte nativo no FM-DX.
- Perfis DiBcom, MaxLinear e HikariSoft são referências técnicas sem VID/PID verificado nesta pesquisa.
- Necessários testes com dongles reais para confirmar USB Host/OTG, firmware, sintonia e fluxo MPEG-TS.
