# FM-DX Android Universal 0.55.0 — HTTPS Radio & TV Intelligence

## Novidades
- Interface web `/internet-media`, protegida por autenticação de administrador.
- Consulta do endpoint `/api/internet-media/inspect` a partir do navegador.
- Resumo visual de mídia, formato, status HTTP, Content-Type, tamanho informado e entradas de playlist.
- Tentativa de reprodução direta usando HTML Audio/Video quando o servidor, o codec e o navegador oferecem suporte.
- Clique em uma entrada de playlist para transferi-la ao campo de análise e examiná-la separadamente.

## Segurança preservada
- URLs submetidas explicitamente pelo usuário.
- Limite de leitura de 256 KiB e timeout de 8 segundos.
- Bloqueio de endereços locais/privados.
- Sem redirecionamento automático, captura de tráfego de terceiros, interceptação TLS ou bypass de DRM/autenticação.

## Limitações
- A reprodução HLS/DASH não é garantida em todos os navegadores; esta versão não inclui hls.js ou dash.js.
- Uma playlist pode conter várias camadas de playlists e segmentos. A versão atual lista entradas diretas, sem varredura recursiva.
- A interface é servida pelo FM-DX Webserver e requer sessão de administrador. Não é um APK independente.
- Testes de reprodução real dependem de URLs públicas autorizadas e de navegador/dispositivo compatível.
