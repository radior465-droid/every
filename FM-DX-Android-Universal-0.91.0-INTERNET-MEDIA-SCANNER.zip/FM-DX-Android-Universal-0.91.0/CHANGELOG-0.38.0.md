# FM-DX Android Universal 0.38.0 — Universal FM Hardware Database

## Novidades
- Novo catálogo conservador de assinaturas de plataforma para Qualcomm, MediaTek, Samsung Exynos, Unisoc, HiSilicon/Kirin e Google Tensor.
- Identificação usa campos públicos do Android quando disponíveis (`Build.SOC_MANUFACTURER`, `Build.SOC_MODEL` e `Build.HARDWARE`). Em Android anterior à API 31, informa a limitação sem inventar o modelo do SoC.
- Histórico local de observações vinculado ao `Build.FINGERPRINT` exato, incluindo fabricante, modelo, SoC exposto, versão Android, resultado e data do teste.
- O laboratório inclui assinatura de plataforma e dados públicos do SoC no relatório.
- Histórico limitado às 100 observações mais recentes; dados permanecem no armazenamento privado do aplicativo.
- `versionName` atualizado para 0.38.0 e `versionCode` para 23.

## Interpretação e limites
- O catálogo identifica famílias de plataforma, não modelos específicos nem suporte FM.
- Marca, SoC, fingerprint, recursos do PackageManager e dispositivos de áudio não comprovam a existência física do tuner, driver/HAL acessível ou funcionamento.
- Nenhuma interface privada, root ou bypass de permissões é utilizado.
- Confirmação de FM exige evidência independente e teste real de sintonia/áudio para o modelo, variante e firmware exatos.
