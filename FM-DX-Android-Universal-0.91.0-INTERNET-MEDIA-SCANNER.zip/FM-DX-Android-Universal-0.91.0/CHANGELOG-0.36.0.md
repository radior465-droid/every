# 0.36.0

- Prioriza Build.SOC_MANUFACTURER/SOC_MODEL para identificar a plataforma quando disponíveis.
- Usa hardware/board/device/product como evidência secundária.
- Não usa marca ou nome comercial do modelo como prova de chipset (Samsung genérico permanece apenas como pista de fabricante).
- Registra recursos de sistema cujos nomes mencionam radio/FM/tuner/telephony, sem tratá-los como prova de receptor FM.
- Inclui versão Android/API e patch de segurança no diagnóstico.
- Atualiza versionCode para 21 e versionName para 0.36.0.
