'use strict';

function sanitizeQueue(value, limit = 100) {
  if (!Array.isArray(value)) return [];
  return value.filter((entry) => entry && typeof entry.url === 'string' && /^https?:\/\//i.test(entry.url) && entry.url.length <= 2048).slice(0, limit);
}

function takeNext(queue) {
  const safe = sanitizeQueue(queue);
  return { next: safe[0] || null, remaining: safe.slice(1) };
}

function findPrevious(history, currentUrl) {
  if (!Array.isArray(history)) return null;
  return history.find((entry) => entry && typeof entry.url === 'string' && entry.url !== currentUrl && /^https?:\/\//i.test(entry.url)) || null;
}

module.exports = { sanitizeQueue, takeNext, findPrevious };
