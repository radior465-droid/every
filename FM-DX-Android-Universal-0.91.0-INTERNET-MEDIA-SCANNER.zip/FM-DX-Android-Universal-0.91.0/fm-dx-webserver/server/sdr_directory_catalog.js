'use strict';

// Curated directory index. Refreshing this endpoint updates the app's index,
// not the live status of individual receivers or the third-party directories.
const SOURCES = Object.freeze([
  { id: 'receiverbook', name: 'ReceiverBook — OpenWebRX', description: 'Mapa e catálogo de receptores OpenWebRX e plataformas compatíveis.', url: 'https://receiverbook.de/', platforms: ['OpenWebRX'], bands: ['Variável por receptor'] },
  { id: 'kiwi-directory', name: 'KiwiSDR — diretório público', description: 'Diretório de receptores KiwiSDR públicos.', url: 'https://rx.kiwisdr.com/', platforms: ['KiwiSDR'], bands: ['LF', 'MF', 'HF (conforme receptor)'] },
  { id: 'kiwi-map', name: 'KiwiSDR — mapa mundial', description: 'Localização geográfica de receptores KiwiSDR.', url: 'https://map.kiwisdr.com/', platforms: ['KiwiSDR'], bands: ['Variável por receptor'] },
  { id: 'websdr', name: 'WebSDR.org — lista de servidores', description: 'Lista de receptores WebSDR independentes.', url: 'https://www.websdr.org/', platforms: ['WebSDR'], bands: ['Variável por receptor'] },
  { id: 'rxtx', name: 'RX-TX.info — mapa de receptores', description: 'Mapa e listagem de estações SDR de diferentes tecnologias.', url: 'https://rx-tx.info/', platforms: ['Múltiplas'], bands: ['Variável por receptor'] },
  { id: 'community-map', name: 'Mapa SDR comunitário', description: 'Mapa independente com referências de várias plataformas SDR.', url: 'https://map-sdr.p00lack.cc/', platforms: ['KiwiSDR', 'OpenWebRX', 'WebSDR', 'Web-888'], bands: ['Variável por receptor'] },
  { id: 'web888', name: 'Web-888 — mapa e lista', description: 'Diretório específico de receptores Web-888.', url: 'https://rx-888.com/', platforms: ['Web-888'], bands: ['Variável por receptor'] },
  { id: 'sdr-global-atlas', name: 'Global SDR Atlas — lista comunitária', description: 'Lista comunitária de servidores SDR com filtros e faixas anunciadas; disponibilidade pode mudar.', url: 'https://sdr.shbrg.nl/sdr/', platforms: ['WebSDR', 'OpenWebRX', 'KiwiSDR', 'PhantomSDR', 'UberSDR'], bands: ['Variável por receptor'] },
  { id: 'kc4mcq-live-sdr', name: 'Live SDR Worldwide — KC4MCQ', description: 'Diretório comunitário mundial de receptores públicos, com pesquisa por localização e plataforma.', url: 'https://kc4mcq.us/live-sdr/', platforms: ['KiwiSDR', 'OpenWebRX', 'WebSDR'], bands: ['Variável por receptor'] },
  { id: 'global-sdr-hub', name: 'Global SDR Hub', description: 'Portal de descoberta que reúne mapas, diretórios e receptores públicos.', url: 'https://pttradio.co.uk/global-sdr/', platforms: ['Múltiplas'], bands: ['Variável por receptor'] },
  { id: 'hams-live-sdr', name: 'hams.live — diretórios SDR', description: 'Página de referência com diretórios de receptores e plataformas SDR.', url: 'https://hams.live/sdr/', platforms: ['KiwiSDR', 'OpenWebRX', 'WebSDR', 'Web-888'], bands: ['Variável por receptor'] }
]);

const DISCOVERY_SEARCHES = Object.freeze([
  { id: 'kiwisdr-search', name: 'Buscar receptores KiwiSDR públicos', description: 'Pesquisa páginas públicas de receptores KiwiSDR.', url: 'https://www.google.com/search?q=public+KiwiSDR+receiver' },
  { id: 'openwebrx-search', name: 'Buscar servidores OpenWebRX públicos', description: 'Pesquisa interfaces públicas OpenWebRX.', url: 'https://www.google.com/search?q=public+OpenWebRX+receiver' },
  { id: 'websdr-search', name: 'Buscar servidores WebSDR públicos', description: 'Pesquisa páginas públicas WebSDR.', url: 'https://www.google.com/search?q=public+WebSDR+receiver' },
  { id: 'web888-search', name: 'Buscar receptores Web-888 públicos', description: 'Pesquisa páginas públicas Web-888.', url: 'https://www.google.com/search?q=public+Web-888+SDR+receiver' },
  { id: 'vhf-uhf-search', name: 'Buscar SDR público com VHF/UHF', description: 'Pesquisa receptores que anunciam cobertura VHF e UHF.', url: 'https://www.google.com/search?q=public+SDR+receiver+VHF+UHF' },
  { id: 'shortwave-search', name: 'Buscar SDR público de ondas curtas', description: 'Pesquisa receptores públicos de HF/ondas curtas.', url: 'https://www.google.com/search?q=public+shortwave+HF+SDR+receiver' }
]);

function getSdrDirectoryCatalog() {
  return { version: 3, updatedAt: new Date().toISOString(), refreshIntervalSeconds: 900, sources: SOURCES.map(source => ({ ...source, platforms: [...source.platforms], bands: [...source.bands] })), discoverySearches: DISCOVERY_SEARCHES.map(item => ({ ...item })), note: 'Catálogo de diretórios e pesquisas públicas para encontrar novos servidores. As pesquisas abrem resultados externos; o aplicativo não rastreia toda a internet nem confirmam a disponibilidade de cada receptor. Consulte a faixa anunciada no servidor antes de usar.' };
}

module.exports = { getSdrDirectoryCatalog };
