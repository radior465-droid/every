'use strict';

// Converts a single, explicitly requested stream inspection into actionable,
// conservative troubleshooting guidance. It does not probe alternate URLs.
function diagnoseInspection(result = {}, browser = {}) {
    const status = Number(result.status);
    const format = String(result.format || 'desconhecido');
    const contentType = String(result.contentType || '').toLowerCase();
    const issues = [];
    let state = 'inconclusivo';
    let cause = 'Não foi possível determinar uma causa única.';
    let action = 'Confira o endereço e tente novamente mais tarde.';

    if (result.redirect || (status >= 300 && status < 400) || String(result.media).includes('redirecionamento')) {
        state = 'redirecionamento'; cause = 'O servidor redirecionou a solicitação.';
        action = 'Use o endereço final oficial fornecido pelo serviço, se você tiver autorização. O FM-DX não segue redirecionamentos automaticamente.';
    } else if (status === 401 || status === 403) {
        state = 'autenticacao'; cause = 'O servidor exige autenticação ou não autorizou o acesso.';
        action = 'Entre pelo método oficial do provedor ou solicite permissão. O diagnóstico não tenta contornar login ou proteção.';
    } else if (status === 404 || status === 410) {
        state = 'endereco-nao-encontrado'; cause = 'O servidor informou que o recurso não existe ou foi removido.';
        action = 'Confirme se o endereço foi atualizado pelo responsável pela transmissão.';
    } else if (status === 429) {
        state = 'limite-de-acesso'; cause = 'O servidor limitou temporariamente as solicitações.';
        action = 'Aguarde antes de tentar novamente e respeite os limites do provedor.';
    } else if (status >= 500) {
        state = 'falha-no-servidor'; cause = 'O servidor remoto retornou um erro interno.';
        action = 'Tente mais tarde ou informe o erro ao administrador da transmissão.';
    } else if (status >= 200 && status < 300) {
        state = 'servidor-respondeu'; cause = 'O endereço respondeu por HTTP, mas isso não garante que o fluxo possa ser reproduzido.';
        action = 'Confira o codec, o suporte do navegador e as permissões CORS; tente o player indicado para o formato.';
    } else if (result.error) {
        const message = String(result.error).toLowerCase();
        if (/timeout|timed out|abort/.test(message)) {
            state = 'tempo-esgotado'; cause = 'A consulta excedeu o tempo limite.';
            action = 'Verifique sua conexão e se o servidor está respondendo; tente novamente mais tarde.';
        } else if (/blocked|private|local|dns|enotfound|eai_again/.test(message)) {
            state = 'destino-bloqueado-ou-dns'; cause = 'O endereço não pôde ser validado ou resolvido com segurança.';
            action = 'Confira o domínio e use somente um endereço público HTTP/HTTPS autorizado.';
        } else {
            state = 'falha-de-conexao'; cause = 'A consulta não conseguiu completar a conexão.';
            action = 'Confira a URL, a conexão e a disponibilidade do servidor.';
        }
    }

    if (status >= 200 && status < 300 && contentType) {
        const expectsAudio = ['MP3', 'AAC', 'OGG', 'OPUS'].includes(format.toUpperCase());
        const expectsVideo = ['MPEG-DASH', 'MPEG-TS'].includes(format.toUpperCase()) || String(result.media).toLowerCase() === 'tv';
        if (expectsAudio && !contentType.startsWith('audio/') && !/mpegurl/.test(contentType)) {
            issues.push('O tipo MIME informado não parece ser áudio; o servidor pode estar enviando um conteúdo diferente do esperado.');
        }
        if (expectsVideo && !contentType.startsWith('video/') && !/dash\+xml|mpegurl/.test(contentType)) {
            issues.push('O tipo MIME informado não parece ser vídeo ou manifesto de streaming.');
        }
    }
    if (browser && browser.cors === 'blocked') issues.push('O navegador informou bloqueio CORS para esta origem.');
    if (browser && browser.cors === 'unknown') issues.push('CORS não foi confirmado pelo diagnóstico; a política do navegador pode impedir a reprodução mesmo com HTTP 2xx.');
    if (browser && browser.canPlayType === '') issues.push('O navegador não indicou suporte ao MIME consultado.');
    if (browser && browser.mse === false && ['HLS', 'MPEG-DASH'].includes(format.toUpperCase())) issues.push('Media Source Extensions não estão disponíveis neste navegador; players baseados em MSE podem não funcionar.');
    if (result.playlist) issues.push('O endereço parece ser uma playlist/manifesto; confirme se é uma lista de canais ou um manifesto de segmentos HLS.');

    return {
        state, cause, action, httpStatus: Number.isFinite(status) ? status : null,
        format, contentType: result.contentType || '', issues,
        limitations: ['O diagnóstico consulta somente a URL enviada.', 'CORS, DRM, autenticação e codecs internos nem sempre podem ser confirmados no servidor.', 'HTTP 2xx não garante reprodução; nenhuma proteção é contornada.']
    };
}

module.exports = { diagnoseInspection };
