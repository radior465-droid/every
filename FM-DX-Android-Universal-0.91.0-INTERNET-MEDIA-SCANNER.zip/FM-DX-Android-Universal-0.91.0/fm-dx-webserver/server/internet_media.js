'use strict';

// Internet media discovery for streams the user explicitly supplies.
// This module does not sniff other apps' traffic or bypass HTTPS/DRM.
const dns = require('node:dns').promises;
const net = require('node:net');

const MAX_BYTES = 256 * 1024;
const TIMEOUT_MS = 6000;
const MAX_PLAYLIST_ENTRIES = 100;
const MAX_SCAN_CONCURRENCY = 4;

function isPrivateAddress(address) {
    const family = net.isIP(address);
    if (family === 4) {
        const p = address.split('.').map(Number);
        return p[0] === 0 || p[0] === 10 || p[0] === 127 ||
            (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
            (p[0] === 192 && p[1] === 168) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127) || p[0] >= 224;
    }
    if (family === 6) {
        const a = address.toLowerCase();
        return a === '::1' || a === '::' || a.startsWith('fc') || a.startsWith('fd') ||
            a.startsWith('fe8') || a.startsWith('fe9') || a.startsWith('fea') || a.startsWith('feb') || a.startsWith('::ffff:127.');
    }
    return true;
}

async function validatePublicUrl(input) {
    let url;
    try { url = new URL(input); } catch { throw new Error('URL inválida.'); }
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Somente URLs HTTP e HTTPS são aceitas.');
    if (url.username || url.password) throw new Error('URLs com usuário ou senha não são aceitas.');
    if (!url.hostname) throw new Error('Host inválido.');
    const records = await dns.lookup(url.hostname, { all: true });
    if (!records.length || records.some(r => isPrivateAddress(r.address))) {
        throw new Error('Destino local ou privado bloqueado por segurança.');
    }
    return url;
}

function classify(contentType = '', url = '', body = '') {
    const type = contentType.toLowerCase().split(';')[0].trim();
    const path = new URL(url).pathname.toLowerCase();
    if (path.endsWith('.m3u8') || body.trimStart().startsWith('#EXTM3U') && body.includes('#EXT-X-')) return { media: 'tv/radio', format: 'HLS', playlist: true };
    if (path.endsWith('.mpd') || type.includes('dash+xml')) return { media: 'tv', format: 'MPEG-DASH', playlist: true };
    if (path.endsWith('.m3u') || type.includes('mpegurl') || body.trimStart().startsWith('#EXTM3U')) return { media: 'radio/tv', format: 'M3U', playlist: true };
    if (type.includes('mpegurl')) return { media: 'radio/tv', format: 'M3U/M3U8', playlist: true };
    if (type.includes('audio/mpeg') || /\.mp3$/.test(path)) return { media: 'radio', format: 'MP3', playlist: false };
    if (type.includes('aac') || /\.aac$/.test(path)) return { media: 'radio', format: 'AAC', playlist: false };
    if (type.includes('ogg') || /\.ogg$/.test(path)) return { media: 'radio', format: 'OGG', playlist: false };
    if (type.includes('opus') || /\.opus$/.test(path)) return { media: 'radio', format: 'Opus', playlist: false };
    if (type.includes('mp2t') || /\.ts$/.test(path)) return { media: 'tv', format: 'MPEG-TS', playlist: false };
    if (type.startsWith('video/')) return { media: 'tv', format: type, playlist: false };
    if (type.startsWith('audio/')) return { media: 'radio', format: type, playlist: false };
    return { media: 'desconhecido', format: type || 'não identificado', playlist: false };
}

function parsePlaylist(body) {
    return parsePlaylistEntries(body).map(entry => entry.url).filter(Boolean);
}

// Parses common M3U metadata without assuming that every entry is a TV channel.
function parsePlaylistEntries(body, baseUrl = 'https://playlist.invalid/') {
    const lines = String(body || '').split(/\r?\n/);
    const entries = [];
    let metadata = {};
    for (const raw of lines) {
        const line = raw.trim();
        if (!line) continue;
        if (line.startsWith('#EXTINF:')) {
            const comma = line.indexOf(',');
            const attrs = line.slice(0, comma < 0 ? undefined : comma);
            const title = comma < 0 ? '' : line.slice(comma + 1).trim();
            const readAttr = name => {
                const match = attrs.match(new RegExp('(?:^|\\s)' + name + '="([^"]*)"', 'i'));
                return match ? match[1].trim() : '';
            };
            metadata = {
                title: readAttr('tvg-name') || title || '',
                tvgId: readAttr('tvg-id'),
                logo: readAttr('tvg-logo'),
                group: readAttr('group-title'),
                duration: (attrs.match(/^#EXTINF:([^,]+)/i) || [])[1] || ''
            };
            continue;
        }
        if (line.startsWith('#')) continue;
        let resolved;
        try { resolved = new URL(line, baseUrl).href; } catch { metadata = {}; continue; }
        const urlPath = (() => { try { return new URL(resolved).pathname.toLowerCase(); } catch { return ''; } })();
        let fallbackTitle = urlPath.split('/').filter(Boolean).pop() || 'Transmissão';
        try { fallbackTitle = decodeURIComponent(fallbackTitle); } catch {}
        const title = metadata.title || fallbackTitle.replace(/\.[a-z0-9]{2,5}$/i, '');
        entries.push({
            url: resolved,
            title: title.slice(0, 180),
            tvgId: metadata.tvgId || '',
            logo: metadata.logo || '',
            group: metadata.group || '',
            media: inferMediaFromEntry(resolved, metadata.group, metadata.title),
            format: inferFormatFromUrl(resolved),
            ftaStatus: inferFtaStatus(metadata.group || '', metadata.title || title)
        });
        metadata = {};
        if (entries.length >= MAX_PLAYLIST_ENTRIES) break;
    }
    return entries;
}

// Only mark FTA when the playlist explicitly labels a channel as open/free-to-air.
// Missing metadata is 'unknown'—a playlist URL cannot prove satellite encryption status.
function inferFtaStatus(group = '', title = '') {
    const hint = `${group} ${title}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    if (/\b(fta|free[ -]?to[ -]?air|livre|aberto|canal aberto)\b/.test(hint)) return 'indicado como FTA';
    if (/\b(encrypted|scrambled|codificado|criptografado)\b/.test(hint)) return 'indicado como codificado';
    return 'não informado';
}

function isHlsSegmentPlaylist(body) {
    return /#EXT-X-TARGETDURATION/i.test(String(body || '')) && !/#EXT-X-STREAM-INF/i.test(String(body || ''));
}

function inferFormatFromUrl(input) {
    let path = '';
    try { path = new URL(input).pathname.toLowerCase(); } catch { return 'desconhecido'; }
    if (path.endsWith('.m3u8')) return 'HLS';
    if (path.endsWith('.mpd')) return 'MPEG-DASH';
    if (path.endsWith('.mp3')) return 'MP3';
    if (path.endsWith('.aac')) return 'AAC';
    if (path.endsWith('.ogg')) return 'OGG';
    if (path.endsWith('.opus')) return 'Opus';
    if (path.endsWith('.ts')) return 'MPEG-TS';
    return 'a identificar';
}

function inferMediaFromEntry(input, group = '', title = '') {
    const hint = `${group} ${title}`.toLowerCase();
    const format = inferFormatFromUrl(input);
    if (['MP3', 'AAC', 'OGG', 'Opus'].includes(format) || /radio|rádio|audio|áudio|fm\b|am\b/.test(hint)) return 'radio';
    if (['MPEG-DASH', 'MPEG-TS'].includes(format) || /tv|televis|canal|video|vídeo/.test(hint)) return 'tv';
    return 'radio/tv';
}

async function probeEntry(entry) {
    try {
        const url = await validatePublicUrl(entry.url);
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
        try {
            const response = await fetch(url, {
                method: 'GET', redirect: 'manual', signal: controller.signal,
                headers: { 'User-Agent': 'FM-DX-Internet-Media-Discovery/0.58', Range: 'bytes=0-0' }
            });
            const status = response.status;
            await response.body?.cancel().catch(() => {});
            let availability = 'indisponível';
            if (status >= 200 && status < 300) availability = 'ativo';
            else if (status === 401 || status === 403) availability = 'requer autorização';
            else if (status >= 300 && status < 400) availability = 'redirecionamento';
            else if (status === 404 || status === 410) availability = 'indisponível';
            else availability = 'não confirmado';
            const contentType = response.headers.get('content-type') || '';
            const detected = classify(contentType, url.href);
            return { ...entry, status, availability, contentType, format: detected.format !== 'não identificado' ? detected.format : entry.format,
                media: detected.media !== 'desconhecido' ? detected.media : entry.media };
        } finally { clearTimeout(timer); }
    } catch (error) {
        return { ...entry, status: null, availability: error.name === 'AbortError' ? 'tempo esgotado' : 'não confirmado', error: error.message };
    }
}

async function scanPlaylist(input) {
    const source = await inspectStream(input);
    if (!source.playlist || !['M3U', 'M3U/M3U8', 'HLS'].includes(source.format)) {
        throw new Error('O endereço informado não retornou uma playlist M3U/M3U8 reconhecida.');
    }
    const playlistUrl = await validatePublicUrl(input);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    let body = '';
    try {
        const response = await fetch(playlistUrl, { method: 'GET', redirect: 'manual', signal: controller.signal,
            headers: { 'User-Agent': 'FM-DX-Internet-Media-Discovery/0.58', Range: `bytes=0-${MAX_BYTES - 1}` } });
        if (!response.ok) throw new Error(`Playlist respondeu HTTP ${response.status}.`);
        const reader = response.body?.getReader();
        const chunks = []; let total = 0;
        if (reader) {
            while (total < MAX_BYTES) {
                const { done, value } = await reader.read();
                if (done) break;
                const part = value.subarray(0, MAX_BYTES - total);
                chunks.push(Buffer.from(part)); total += part.length;
                if (part.length < value.length) break;
            }
            await reader.cancel().catch(() => {});
        }
        body = Buffer.concat(chunks).toString('utf8');
    } finally { clearTimeout(timer); }
    if (isHlsSegmentPlaylist(body)) {
        throw new Error('Este endereço é uma playlist HLS de segmentos, não uma lista de canais M3U. Use Analisar link para reproduzi-la.');
    }
    const entries = parsePlaylistEntries(body, playlistUrl.href);
    const results = new Array(entries.length);
    let cursor = 0;
    async function worker() {
        while (cursor < entries.length) {
            const index = cursor++;
            results[index] = await probeEntry(entries[index]);
        }
    }
    await Promise.all(Array.from({ length: Math.min(MAX_SCAN_CONCURRENCY, entries.length) }, worker));
    return { url: playlistUrl.href, format: source.format, total: results.length,
        active: results.filter(x => x.availability === 'ativo').length,
        unavailable: results.filter(x => x.availability === 'indisponível').length,
        entries: results };
}

// Imports up to ten user-supplied playlists into one deduplicated catalogue.
function buildUnifiedCatalogue(sources) {
    const catalogue = new Map();
    let duplicates = 0;
    for (const source of sources) {
        for (const entry of source.entries) {
            let key;
            if (entry.tvgId) key = `id:${entry.tvgId.trim().toLowerCase()}`;
            else { try { const canonical = new URL(entry.url); canonical.hash = ''; key = `url:${canonical.href}`; } catch { key = `url:${entry.url}`; } }
            if (catalogue.has(key)) {
                duplicates++;
                const previous = catalogue.get(key);
                // Prefer an entry with a logo or a confirmed active status.
                if ((!previous.logo && entry.logo) || (previous.availability !== 'ativo' && entry.availability === 'ativo')) {
                    catalogue.set(key, { ...previous, ...entry, sources: [...new Set([...(previous.sources || []), source.url])] });
                } else previous.sources = [...new Set([...(previous.sources || []), source.url])];
            } else catalogue.set(key, { ...entry, sources: [source.url] });
        }
    }
    const entries = [...catalogue.values()].sort((a, b) => a.title.localeCompare(b.title, 'pt-BR', { sensitivity: 'base' }));
    return { entries, duplicates };
}

async function importPlaylists(inputs) {
    if (!Array.isArray(inputs) || inputs.length < 1 || inputs.length > 10) {
        throw new Error('Informe de 1 a 10 playlists por importação.');
    }
    const urls = [...new Set(inputs.map(value => String(value || '').trim()).filter(Boolean))];
    if (urls.length > 10 || urls.some(value => value.length > 2048)) {
        throw new Error('Cada endereço deve ter até 2048 caracteres e o limite é 10 playlists.');
    }
    const sources = [];
    const failures = [];
    // Sequential playlist scans keep aggregate network pressure bounded.
    for (const url of urls) {
        try { sources.push(await scanPlaylist(url)); }
        catch (error) { failures.push({ url, error: error.message }); }
    }
    const unified = buildUnifiedCatalogue(sources);
    const entries = unified.entries;
    return { playlistCount: urls.length, scannedPlaylists: sources.length, failedPlaylists: failures.length, total: entries.length, duplicates: unified.duplicates, active: entries.filter(x => x.availability === 'ativo').length, unavailable: entries.filter(x => x.availability === 'indisponível').length, failures, entries };
}

// Rechecks only URLs already present in the user's local catalogue.
async function recheckEntries(entries) {
    if (!Array.isArray(entries) || entries.length < 1 || entries.length > MAX_PLAYLIST_ENTRIES) {
        throw new Error('Informe de 1 a 100 canais para atualizar.');
    }
    if (entries.some(entry => !entry || typeof entry.url !== 'string' || entry.url.length > 2048)) {
        throw new Error('Cada canal precisa conter uma URL válida de até 2048 caracteres.');
    }
    const results = new Array(entries.length);
    let cursor = 0;
    async function worker() {
        while (cursor < entries.length) {
            const index = cursor++;
            results[index] = await probeEntry(entries[index]);
        }
    }
    await Promise.all(Array.from({ length: Math.min(MAX_SCAN_CONCURRENCY, entries.length) }, worker));
    return { checkedAt: new Date().toISOString(), total: results.length, active: results.filter(x => x.availability === 'ativo').length, unavailable: results.filter(x => x.availability === 'indisponível').length, results };
}

async function inspectStream(input) {
    const url = await validatePublicUrl(input);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
        const response = await fetch(url, {
            method: 'GET', redirect: 'manual', signal: controller.signal,
            headers: { 'User-Agent': 'FM-DX-Internet-Media-Discovery/0.54', 'Range': `bytes=0-${MAX_BYTES - 1}` }
        });
        if (response.status >= 300 && response.status < 400) {
            return { url: url.href, status: response.status, media: 'redirecionamento', format: 'URL redirecionada; não seguida automaticamente', playlist: false, playable: false };
        }
        const reader = response.body?.getReader();
        let chunks = [], total = 0;
        if (reader) {
            while (total < MAX_BYTES) {
                const { done, value } = await reader.read();
                if (done) break;
                const part = value.subarray(0, MAX_BYTES - total);
                chunks.push(part); total += part.length;
                if (part.length < value.length) break;
            }
            await reader.cancel().catch(() => {});
        }
        const buffer = Buffer.concat(chunks);
        const contentType = response.headers.get('content-type') || '';
        const text = /mpegurl|dash\+xml|text\/plain/i.test(contentType) || /\.(m3u8?|mpd)$/i.test(url.pathname) ? buffer.toString('utf8') : '';
        const result = classify(contentType, url.href, text);
        const entries = result.playlist ? parsePlaylist(text) : [];
        return {
            url: url.href, status: response.status, contentType, contentLength: response.headers.get('content-length'),
            media: result.media, format: result.format, playlist: result.playlist,
            entries: entries.map(entry => { try { return new URL(entry, url).href; } catch { return null; } }).filter(Boolean),
            playable: response.ok && !result.playlist && result.media !== 'desconhecido',
            note: response.status === 401 || response.status === 403 ? 'Acesso exige autorização; não tente contornar a proteção.' : undefined
        };
    } finally { clearTimeout(timer); }
}



const SDR_TIMEOUT_MS = 7000;
const SDR_MAX_BYTES = 192 * 1024;
function classifySdrServer(url, body = '', contentType = '') {
    const text = String(body || '').slice(0, SDR_MAX_BYTES);
    const lower = `${url.hostname} ${url.pathname} ${text.slice(0, 50000)}`.toLowerCase();
    let platform = 'SDR não identificado';
    if (/kiwisdr|kiwi[-_ ]?sdr|\bkiwi\b/.test(lower)) platform = 'KiwiSDR';
    else if (/openwebrx|open-web-rx|openwebrx-ng/.test(lower)) platform = 'OpenWebRX';
    else if (/websdr|web sdr/.test(lower)) platform = 'WebSDR';
    else if (/sdr\s*#|sdrsharp|airspy|spyserver/.test(lower)) platform = 'SpyServer / SDR#';
    const ranges = [];
    const seen = new Set();
    // Parse explicitly advertised frequency pairs, not arbitrary numbers in page scripts.
    const patterns = [
        /(?:min(?:imum)?[_ -]?(?:freq(?:uency)?)?\s*[:=]\s*)(\d+(?:\.\d+)?)\s*(k?hz|mhz)?[\s\S]{0,160}?(?:max(?:imum)?[_ -]?(?:freq(?:uency)?)?\s*[:=]\s*)(\d+(?:\.\d+)?)\s*(k?hz|mhz)?/ig,
        /(?:frequency|frequencies|freq(?:uency)?[_ -]?range)[^\n<]{0,100}?(\d+(?:\.\d+)?)\s*(k?hz|mhz)\s*(?:-|–|to|a)\s*(\d+(?:\.\d+)?)\s*(k?hz|mhz)/ig
    ];
    const toHz = (value, unit) => Number(value) * (/mhz/i.test(unit || '') ? 1e6 : /khz/i.test(unit || '') ? 1e3 : 1);
    for (const re of patterns) {
        let match;
        while ((match = re.exec(text)) && ranges.length < 20) {
            let low, high;
            if (re === patterns[0]) { low = toHz(match[1], match[2]); high = toHz(match[3], match[4]); }
            else { low = toHz(match[1], match[2]); high = toHz(match[3], match[4]); }
            if (Number.isFinite(low) && Number.isFinite(high) && low > 0 && high > low && high <= 3e9) {
                const key = `${low}-${high}`;
                if (!seen.has(key)) { seen.add(key); ranges.push({ minHz: low, maxHz: high, label: `${(low/1e6).toFixed(3)}–${(high/1e6).toFixed(3)} MHz` }); }
            }
        }
    }
    return { platform, ranges, supported: platform !== 'SDR não identificado', contentType };
}

async function scanSdrUrl(input) {
    const url = await validatePublicUrl(input);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), SDR_TIMEOUT_MS);
    try {
        const response = await fetch(url, { method: 'GET', redirect: 'manual', signal: controller.signal,
            headers: { 'User-Agent': 'FM-DX-SDR-URL-Scanner/0.84', Range: `bytes=0-${SDR_MAX_BYTES - 1}` } });
        if (response.status >= 300 && response.status < 400) {
            await response.body?.cancel().catch(() => {});
            return { url: url.href, status: response.status, platform: 'Redirecionamento', supported: false, ranges: [], note: 'O redirecionamento não foi seguido. Informe a URL final do servidor SDR.' };
        }
        const reader = response.body?.getReader();
        const chunks = []; let total = 0;
        if (reader) {
            while (total < SDR_MAX_BYTES) {
                const { done, value } = await reader.read(); if (done) break;
                const part = value.subarray(0, SDR_MAX_BYTES - total); chunks.push(part); total += part.length;
                if (part.length < value.length) break;
            }
            await reader.cancel().catch(() => {});
        }
        const body = Buffer.concat(chunks).toString('utf8');
        const contentType = response.headers.get('content-type') || '';
        const detected = classifySdrServer(url, body, contentType);
        return { url: url.href, status: response.status, ...detected,
            availability: response.ok ? 'respondendo' : response.status === 401 || response.status === 403 ? 'requer autorização' : 'resposta HTTP não confirmada',
            note: detected.ranges.length ? 'Faixas extraídas somente quando anunciadas explicitamente pela página.' : 'O servidor não publicou limites de frequência reconhecíveis nesta página. Abra a interface SDR para consultar as faixas disponíveis.' };
    } finally { clearTimeout(timer); }
}

module.exports = { scanSdrUrl, classifySdrServer, inspectStream, scanPlaylist, importPlaylists, recheckEntries, buildUnifiedCatalogue, classify, parsePlaylist, parsePlaylistEntries, inferFormatFromUrl, inferMediaFromEntry, inferFtaStatus, isHlsSegmentPlaylist, validatePublicUrl, isPrivateAddress };
