const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('catálogo USB contém apenas perfis explícitos e documenta limites', () => {
  const source = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/TvUsbChipsetCatalog.kt'), 'utf8');
  assert.match(source, /0x0bda, productId = 0x2838/);
  assert.match(source, /0x0bda, productId = 0x2832/);
  assert.match(source, /Sem driver Android universal integrado/);
  assert.match(source, /Chipset não catalogado/);
  assert.match(source, /nunca comprova\s+revisão de placa/);
});


test('catálogo ISDB-T inclui IDs documentados sem prometer integração Android', () => {
  const source = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/TvUsbChipsetCatalog.kt'), 'utf8');
  for (const id of ['0x048d, productId = 0x275a', '0x048d, productId = 0x9308', '0x3275, productId = 0x0080', '0x187f, productId = 0x0600', '0x187f, productId = 0x0302']) assert.ok(source.includes(id), `missing ${id}`);
  assert.match(source, /não é driver APK integrado ao FM-DX/);
  assert.match(source, /integração FM-DX ainda não implementada/);
});

test('referências sem VID/PID são separadas dos perfis USB', () => {
  const source = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/IsdbtHardwareReferences.kt'), 'utf8');
  assert.match(source, /DiBcom DIB8076/);
  assert.match(source, /MaxLinear MxL683/);
  assert.match(source, /HikariSoft ISDB-TB1 \/ ISDB-TB2/);
  assert.match(source, /VID\/PID USB confirmado/);
});
