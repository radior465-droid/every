'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '../../android/app/src/main');

test('TV BOX CONNECT descobre SSDP/UPnP e mantém descoberta DNS-SD', () => {
  const source = fs.readFileSync(path.join(root, 'java/br/com/fmdx/android/tvbox/TvBoxConnectDiscovery.kt'), 'utf8');
  assert.match(source, /M-SEARCH \* HTTP\/1\.1/);
  assert.match(source, /239\.255\.255\.250/);
  assert.match(source, /locationUrl/);
  assert.match(source, /discoverServices\(type, NsdManager\.PROTOCOL_DNS_SD/);
  assert.match(source, /_upnp\._tcp\./);
  assert.match(source, /_dlna\._tcp\./);
});

test('descoberta local não adiciona varredura de portas nem autenticação', () => {
  const source = fs.readFileSync(path.join(root, 'java/br/com/fmdx/android/tvbox/TvBoxConnectDiscovery.kt'), 'utf8');
  assert.doesNotMatch(source, /Socket\([^)]*,\s*\d+\)/);
  assert.doesNotMatch(source, /password|Authorization:|Basic /i);
  const manifest = fs.readFileSync(path.join(root, 'AndroidManifest.xml'), 'utf8');
  assert.match(manifest, /CHANGE_WIFI_MULTICAST_STATE/);
});
