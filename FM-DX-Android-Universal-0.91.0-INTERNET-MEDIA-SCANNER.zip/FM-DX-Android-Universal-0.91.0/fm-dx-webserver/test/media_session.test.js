'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const page = fs.readFileSync(path.join(__dirname, '../web/internet-media.ejs'), 'utf8');

test('integração Media Session é opcional e detecta suporte', () => {
  assert.match(page, /'mediaSession' in navigator/);
  assert.match(page, /function installMediaSession\(\)/);
});
test('metadados do canal atual são publicados sem confiar em HTML', () => {
  assert.match(page, /new MediaMetadata\(/);
  assert.match(page, /String\(currentPlayback\.title/);
});
test('controles do sistema incluem play, pause, stop, próximo e anterior', () => {
  for (const action of ['play','pause','stop','nexttrack','previoustrack']) assert.match(page, new RegExp(`${action}:`));
});
test('estado da sessão acompanha reprodução e pausa', () => {
  assert.match(page, /updateMediaSession\('playing'\)/);
  assert.match(page, /updateMediaSession\('paused'\)/);
  assert.match(page, /updateMediaSession\('none'\)/);
});
test('último canal recebe persistência adicional ao sair da página', () => {
  assert.match(page, /addEventListener\('pagehide'/);
  assert.match(page, /fmdx-last-playback/);
});
test('Android incrementa versão para 0.91.0 e mantém Media3', () => {
  const gradle = fs.readFileSync(path.join(__dirname, '../../android/app/build.gradle'), 'utf8');
  assert.match(gradle, /versionCode 65/);
  assert.match(gradle, /versionName '0\.91\.0'/);
  assert.match(gradle, /media3-exoplayer-hls/);
  assert.match(gradle, /media3-exoplayer-dash/);
});

test('serviço nativo declara reprodução em primeiro plano e ações de mídia', () => {
  const manifest = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/AndroidManifest.xml'), 'utf8');
  const service = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/playback/BackgroundAudioService.kt'), 'utf8');
  assert.match(manifest, /foregroundServiceType="mediaPlayback"/);
  for (const action of ['ACTION_PLAY', 'ACTION_PAUSE', 'ACTION_RESUME', 'ACTION_NEXT', 'ACTION_PREVIOUS', 'ACTION_STOP']) assert.match(service, new RegExp(action));
});

test('biblioteca oferece envio de rádios ao serviço nativo', () => {
  assert.match(page, /FMDXNativeAudio\.start/);
  assert.match(page, /Áudio nativo em segundo plano/);
  assert.match(page, /centralNativeBackground/);
});
test('ponte Android restringe a URL e o tipo de mídia', () => {
  const bridge = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/playback/NativeAudioJavascriptBridge.kt'), 'utf8');
  const validator = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/playback/NativeAudioRequestValidator.kt'), 'utf8');
  assert.match(bridge, /StreamUrlValidator\.normalize/);
  assert.match(bridge, /NativeAudioRequestValidator\.isSupported/);
  assert.match(validator, /MPEG-DASH/);
  assert.match(validator, /M3U8/);
});


test('serviço nativo recebe fila, limita itens e avança ao terminar', () => {
  const service = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/playback/BackgroundAudioService.kt'), 'utf8');
  const bridge = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/playback/NativeAudioJavascriptBridge.kt'), 'utf8');
  assert.match(service, /EXTRA_QUEUE/);
  assert.match(service, /minOf\(json\.length\(\), 100\)/);
  assert.match(service, /Player\.STATE_ENDED/);
  assert.match(service, /ExoPlayer\.Builder/);
  assert.match(service, /moveQueue\(1\)/);
  assert.match(service, /ACTION_NEXT/);
  assert.match(service, /ACTION_PREVIOUS/);
  assert.match(bridge, /queueJson/);
});
test('central envia histórico e fila ao player nativo', () => {
  assert.match(page, /playbackHistory\.slice\(\)\.reverse\(\)/);
  assert.match(page, /JSON\.stringify\(unique\.slice\(0,100\)\)/);
  assert.match(page, /nativePlaybackActive/);
});


test('diagnóstico TV USB lista descritores e solicita permissão Android', () => {
  const discovery = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/UsbTvReceiverDiscovery.kt'), 'utf8');
  const activity = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/MainActivity.kt'), 'utf8');
  assert.match(discovery, /interfaceSubclass/);
  assert.match(discovery, /interfaceProtocol/);
  assert.match(discovery, /usb\.requestPermission/);
  assert.match(discovery, /UsbManager\.EXTRA_PERMISSION_GRANTED/);
  assert.match(activity, /SOLICITAR PERMISSÃO USB/);
});

test('documentação não promete recepção universal de dongles', () => {
  const changelog = fs.readFileSync(path.join(__dirname, '../../CHANGELOG-0.71.0.md'), 'utf8');
  assert.match(changelog, /Não implementa sintonia RF/);
  assert.match(changelog, /drivers específicos/);
});
