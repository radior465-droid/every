const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv');

test('transporte USB exige permissão e endpoint bulk-IN explícito', () => {
  const source = fs.readFileSync(path.join(root, 'UsbBulkTsTransport.kt'), 'utf8');
  assert.match(source, /usbManager\.hasPermission\(device\)/);
  assert.match(source, /USB_ENDPOINT_XFER_BULK/);
  assert.match(source, /USB_DIR_IN/);
  assert.match(source, /claimInterface/);
  assert.match(source, /releaseInterface/);
});

test('transporte USB documenta que não inicializa chipset nem sintoniza', () => {
  const source = fs.readFileSync(path.join(root, 'UsbBulkTsTransport.kt'), 'utf8');
  assert.match(source, /Não envia comandos de sintonia/);
  assert.match(source, /chipset\/firmware/);
});

test('alinhador MPEG-TS trabalha com pacotes de 188 bytes', () => {
  const source = fs.readFileSync(path.join(root, 'UsbBulkTsTransport.kt'), 'utf8');
  assert.match(source, /MpegTsAnalyzer\.PACKET_SIZE/);
  assert.match(source, /0x47/);
  assert.match(source, /class MpegTsPacketAligner/);
});

test('adaptador IT9175 identifica 048D:275A e enumera evidências sem presumir sintonia', () => {
  const source = fs.readFileSync(path.join(root, 'It9175Adapter.kt'), 'utf8');
  assert.match(source, /VENDOR_ID = 0x048d/);
  assert.match(source, /PRODUCT_ID = 0x275a/);
  assert.match(source, /INTERFACES_ENUMERATED/);
  assert.match(source, /USB_PERMISSION_REQUIRED/);
  assert.match(source, /STREAM_NOT_VERIFIED/);
  assert.match(source, /maxPacketSize/);
});

test('adaptador IT9175 não envia comandos enquanto o protocolo não estiver validado', () => {
  const source = fs.readFileSync(path.join(root, 'It9175Adapter.kt'), 'utf8');
  assert.match(source, /UnsupportedOperationException/);
  assert.match(source, /protocolo\/firmware ainda não validada/);
  assert.match(source, /não envia transferências vendor-specific/i);
});

test('diagnóstico USB incorpora relatório específico do IT9175', () => {
  const source = fs.readFileSync(path.join(root, 'UsbTvReceiverDiscovery.kt'), 'utf8');
  assert.match(source, /It9175Adapter\.probe/);
  assert.match(source, /ADAPTADOR IT9175/);
});
