const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { getSdrDirectoryCatalog } = require('../server/sdr_directory_catalog');

test('catálogo SDR público contém diretórios conhecidos e aviso de disponibilidade', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'web', 'internet-media.ejs'), 'utf8');
  const catalog = getSdrDirectoryCatalog();
  const urls = catalog.sources.map(source => source.url);
  for (const url of ['https://receiverbook.de/', 'https://rx.kiwisdr.com/', 'https://map.kiwisdr.com/', 'https://www.websdr.org/', 'https://rx-tx.info/', 'https://map-sdr.p00lack.cc/', 'https://rx-888.com/', 'https://sdr.shbrg.nl/sdr/', 'https://kc4mcq.us/live-sdr/', 'https://pttradio.co.uk/global-sdr/', 'https://hams.live/sdr/']) {
    assert.ok(urls.includes(url), `URL ausente no catálogo: ${url}`);
  }
  assert.match(html, /sdr-directory-catalog/);
  assert.match(html, /noopener noreferrer/);
  assert.match(catalog.note, /não rastreia toda a internet/i);
});
