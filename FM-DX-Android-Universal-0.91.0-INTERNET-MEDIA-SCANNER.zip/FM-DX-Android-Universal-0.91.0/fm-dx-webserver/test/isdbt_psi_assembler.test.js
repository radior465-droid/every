const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');

test('0.77.0 inclui montador PSI/SI com fragmentação, pointer_field e continuidade', () => {
  const source = fs.readFileSync(path.join(root, 'android/app/src/main/java/br/com/fmdx/android/tv/PsiSectionAssembler.kt'), 'utf8');
  assert.match(source, /class PsiSectionAssembler/);
  assert.match(source, /payloadUnitStart/);
  assert.match(source, /pointer/);
  assert.match(source, /continuityCounter/);
  assert.match(source, /sectionLength > 1021/);
});

test('documentação não afirma que o assembler sintoniza ou valida CRC', () => {
  const doc = fs.readFileSync(path.join(root, 'docs/ISDBT-PSI-SECTION-ASSEMBLY.md'), 'utf8');
  assert.match(doc, /não valida CRC-32 MPEG-2/);
  assert.match(doc, /não substitui o driver IT9175/);
});
