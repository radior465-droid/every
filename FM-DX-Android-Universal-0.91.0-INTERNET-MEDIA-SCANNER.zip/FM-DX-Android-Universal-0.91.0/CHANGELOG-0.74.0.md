# FM-DX Android Universal 0.74.0 — Transporte USB bulk-IN

## Implementado
- Camada experimental `UsbBulkTsTransport` para abrir dispositivo USB após permissão Android.
- Validação de índice de interface e endpoint bulk-IN explicitamente informado.
- Reserva/liberação da interface e fechamento controlado da conexão.
- Leitura em blocos limitados a 16 KiB, com timeout para não bloquear indefinidamente.
- `MpegTsPacketAligner` para alinhar o fluxo em pacotes MPEG-TS de 188 bytes, inclusive quando os pacotes chegam divididos entre leituras.
- Testes unitários para alinhamento em blocos e descarte de ruído inicial.

## Limitações técnicas
Esta camada é transporte genérico, não um driver ISDB-T completo. Ela não conhece os comandos proprietários de inicialização, firmware, I2C, demodulador ou tuner RF. O endpoint bulk-IN precisa ser determinado a partir da documentação/protocolo do modelo específico; não se deve escolher um endpoint aleatório e presumir que seja vídeo. Mesmo que bytes sejam recebidos, é necessário validar sincronismo MPEG-TS, PAT/PMT e continuidade antes de afirmar recepção funcional. Não há sintonia ao vivo implementada nesta versão.

## Validação
- Suíte web Node.js: 40 testes aprovados.
- Novos testes Kotlin adicionados; execução Android/Gradle e teste físico dependem de SDK, dependências e dongle compatível.
- APK não compilado neste ambiente.
