## Versão 0.91.0 — INTERNET MEDIA SCANNER + descoberta SSDP/UPnP

Amplia a descoberta local do TV BOX CONNECT: além de DNS-SD/mDNS, consulta anúncios SSDP/UPnP na rede Wi-Fi e apresenta a URL `LOCATION` da descrição do dispositivo, o endereço IP, a porta e o tipo de serviço anunciado. A descoberta é somente de leitura e não varre portas, não tenta autenticação nem extrai canais protegidos. A URL `LOCATION` é a descrição do dispositivo, não necessariamente uma URL de áudio/vídeo; fontes de mídia precisam ser oferecidas pelo próprio equipamento/servidor e ter autorização de uso. A central Internet Media continua analisando URLs e playlists M3U/M3U8 fornecidas pelo usuário, com player integrado para formatos suportados.

## Versão 0.90.0 — TV BOX CONNECT (descoberta local inicial)

Adiciona a tela TV BOX CONNECT e descoberta DNS-SD/mDNS de serviços anunciados na rede local: Google Cast, Android TV Remote, AirPlay, HTTP e HTTPS. A função identifica nome, tipo de serviço, host e porta quando anunciados. **Não** faz varredura de portas/IPs, autenticação, captura de áudio/vídeo, desbloqueio de canais ou contorno de DRM/HDCP. A reprodução dependerá de API oficial, URL autorizada fornecida pelo equipamento/provedor ou capturadora USB UVC compatível.

## Versão 0.86.0 — Atualização automática do catálogo SDR

O catálogo de diretórios SDR agora é fornecido por um endpoint autenticado, carregado ao abrir a página, atualizável manualmente e renovado automaticamente a cada 15 minutos. Essa atualização renova o índice do aplicativo; não representa monitoramento em tempo real nem teste de disponibilidade dos receptores de terceiros. Consulte `CHANGELOG-0.86.0.md`.

## Versão 0.85.0 — Catálogo público de servidores SDR
Adiciona à tela Internet Radio & TV uma seção de diretórios públicos para localizar receptores KiwiSDR, OpenWebRX, WebSDR e Web-888. Os links levam aos diretórios de terceiros; não representam receptores individuais nem garantem disponibilidade. O catálogo não faz varredura global de hosts nem testa automaticamente todos os serviços. Consulte `CHANGELOG-0.85.0.md`.

## Versão 0.84.0 — Scanner SDR remoto por URL
Adiciona análise de URL pública de interfaces SDR remotas, com reconhecimento heurístico de KiwiSDR, OpenWebRX, WebSDR e SpyServer/SDR#, além da extração limitada de faixas explicitamente anunciadas pela página. O recurso não faz descoberta global de servidores nem sintonia RF: cada receptor remoto determina suas próprias faixas e permissões. Consulte `CHANGELOG-0.84.0.md`.

## Versão 0.80.0 — Decodificação ARIB STD-B24 para SI/EPG
O parser SI/EPG agora utiliza um decodificador ARIB STD-B24 parcial para conjuntos alfanumérico, hiragana, katakana e Kanji mapeado via EUC-JP, com designação G0–G3, locking shifts e single shifts. DRCS, mosaicos, macros, símbolos adicionais e controles de apresentação continuam fora do escopo; consulte `CHANGELOG-0.80.0.md`. Isso melhora a leitura de nomes e programação, mas não implementa sintonia RF nem valida recepção física.

## Versão 0.79.0 — SI: emissoras e programação
A versão adiciona parsing inicial de SDT/EIT com validação CRC, nomes de serviço/provedor e metadados básicos de eventos (título, resumo, início MJD/BCD e duração). A decodificação ARIB STD-B24, LCN, sintonia RF e integração física do IT9175 continuam pendentes. Consulte `CHANGELOG-0.79.0.md`.

## Versão 0.78.0 — Descoberta de serviços de TV
A versão adiciona validação de CRC MPEG-2 e descoberta incremental de programas a partir das tabelas PAT/PMT do MPEG-TS. O catálogo associa cada programa aos PIDs de vídeo, áudio, PCR e outros fluxos. Isso só funciona depois que algum backend entrega um fluxo MPEG-TS válido; não significa que o IT9175 já esteja inicializado ou que a sintonia RF esteja implementada. Consulte `CHANGELOG-0.78.0.md`.

## Versão 0.77.0 — Reassemblagem de tabelas PSI/SI do fluxo ISDB-T
A versão adiciona um montador de seções PSI/SI a partir de pacotes MPEG-TS de 188 bytes: trata cabeçalho, campo de adaptação, `payload_unit_start_indicator`, `pointer_field`, seções divididas entre pacotes, múltiplas seções no mesmo payload e perda de continuidade. É uma camada de análise do fluxo recebido, não um driver USB nem uma implementação de sintonia RF. Consulte `CHANGELOG-0.77.0.md`.

## Versão 0.76.0 — Plano de integração ISDB-T OpenDTV
A versão adiciona uma matriz de compatibilidade documentada para IT9175/PT275 (`048D:275A`) e IT9308 (`048D:9308`), além de uma trilha de integração com o projeto Android OpenDTV. O catálogo diferencia suporte upstream confirmado em hardware de suporte que ainda precisa de testes. Nenhum código upstream foi copiado nem driver de TV foi ativado nesta etapa. Consulte `CHANGELOG-0.76.0.md` e `docs/ISDBT-OPENDTV-INTEGRATION.md`.

## Versão 0.75.0 — Adaptador de identificação IT9175
A versão acrescenta um adaptador conservador para o perfil USB ITE/Afatech IT9175 (048D:275A): enumera interfaces e endpoints, registra direção/tipo/tamanho de pacote e distingue identificação, permissão e protocolo ainda não implementado. Não transmite comandos vendor-specific nem firmware, não sintoniza RF e não declara recepção de TV. A referência pública OpenDTV documenta suporte em hardware ao PT275/IT9175 com esse ID USB; consulte `CHANGELOG-0.75.0.md`.

## Versão 0.74.0 — Transporte USB bulk-IN e preparação MPEG-TS
Foi adicionada uma camada experimental de leitura USB bulk-IN com verificação de permissão, seleção explícita de interface/endpoint, reserva e liberação da interface e encerramento controlado. O alinhador MPEG-TS reorganiza bytes recebidos em pacotes de 188 bytes. **Limite importante:** isso não inicializa o tuner/demodulador, não envia comandos de sintonia e não garante que o endpoint escolhido carregue MPEG-TS. A seleção de endpoint e o protocolo de inicialização continuam específicos de cada chipset/firmware. Consulte `CHANGELOG-0.74.0.md`.

## Versão 0.73.0 — Inteligência de compatibilidade ISDB-T/SBTVD
O catálogo agora inclui perfis de IDs USB ISDB-T reportados em projetos públicos (ITE/Afatech IT9175, IT9308 e Siano RIO), além de referências técnicas separadas para DIB8076, MaxLinear MxL683 e HikariSoft ISDB-TB1/TB2 quando não há VID/PID confirmado. A identificação é baseada em evidência pública e não promete recepção ao vivo nem driver Android integrado. Os perfis Siano exigem firmware e o projeto consultado descreve uso Android via Termux, não um APK integrado. Consulte `CHANGELOG-0.73.0.md`.

## Versão 0.72.0 — Catálogo inicial de chipsets de TV USB
O diagnóstico agora consulta um catálogo local conservador por VID/PID, inicialmente com famílias Realtek RTL2832U/RTL2832 associadas a dongles DVB-T. O relatório informa família provável, padrão associado, confiança e situação do driver. IDs desconhecidos não recebem identificação inventada. A correspondência USB não confirma o tuner RF, firmware, revisão da placa nem funcionamento no Android. Importante: DVB-T não é ISDB-T/SBTVD; reconhecer esses dispositivos não habilita recepção de TV brasileira. Nenhum driver universal foi adicionado. Consulte `CHANGELOG-0.72.0.md`.

## Versão 0.71.0 — Diagnóstico avançado de TV USB

A tela TV USB agora lista classe, subclasse e protocolo de cada interface, além de VID/PID, e permite solicitar a permissão USB pelo diálogo oficial do Android. A concessão de permissão apenas autoriza comunicação com o dispositivo: não instala driver, não identifica com certeza o chipset e não inicia sintonia/captura. A recepção ao vivo continua dependente de suporte específico ao tuner/demodulador, firmware/protocolo e padrão de transmissão (no Brasil, ISDB-T). Consulte `CHANGELOG-0.71.0.md`.

## FM-DX Universal 0.69.0 — Fila nativa e troca de estações
A reprodução nativa em segundo plano agora recebe uma fila filtrada de rádios diretas, com controles anterior/próxima na notificação e avanço automático ao terminar uma transmissão. O histórico recente, a estação atual e a fila web são combinados, sem duplicatas e com limite de 100 itens. HLS/DASH, playlists, TV e vídeo continuam fora do player nativo simples. Consulte `CHANGELOG-0.69.0.md`.

## FM-DX Universal 0.68.0 — Biblioteca conectada ao áudio nativo

A biblioteca de rádios agora oferece a ação **Áudio nativo em segundo plano** para estações compatíveis. Também é possível enviar o canal selecionado na central de reprodução ou um item da fila ao serviço Android. O player nativo é uma sessão separada do player web e aceita somente fluxos diretos de áudio HTTP/HTTPS; HLS/DASH, playlists e TV não são suportados por este player simples. A notificação oferece pausar, retomar e parar. Consulte `CHANGELOG-0.68.0.md`.

## Versão 0.83.0 — Linha do tempo de legendas ISDB-T
Foi adicionada uma camada limitada para organizar cues de legenda textual com tempo de início/fim, decodificação ARIB B24 de blocos de texto já extraídos, consulta da legenda ativa, deduplicação e histórico limitado. **Ainda não** existe demultiplexação PES, parsing completo de grupos ARIB de legenda, sincronização PCR/PTS ou renderização DRCS/bitmap/posicionamento; portanto, isso não equivale a closed captions reais recebidas do dongle. Consulte `CHANGELOG-0.83.0.md`.

# FM-DX Android Universal 0.60.0 — Guia Inteligente de Fontes

Projeto de código-fonte para diagnóstico de hardware FM, experimentação com transporte de TV digital e análise explícita de streams de rádio/TV pela Internet.

## 0.60.0 — Guia inteligente de fontes autorizadas
- Guia pessoal para cadastrar URLs de playlists que o usuário tem autorização para utilizar.
- Organização por país, categoria e formato, com pesquisa e filtros.
- Seleção de fontes cadastradas e envio direto ao fluxo existente de importação de até 10 playlists.
- Cadastro, seleção e exclusão persistidos localmente no navegador; não há sincronização entre dispositivos.
- Não existe catálogo remoto pré-preenchido, raspagem automática de diretórios ou validação de direitos sobre as fontes; o usuário deve cadastrar somente endereços cujo uso esteja autorizado.

## 0.58.0 — Biblioteca universal de rádio e TV
- Importação de até 10 playlists M3U/M3U8 por operação, com consultas sequenciais para limitar carga no servidor.
- Consolidação das entradas em uma biblioteca única, com deduplicação por `tvg-id` e, quando ausente, por URL sem fragmento.
- Quando há duplicatas, prioriza metadados de logo e disponibilidade ativa e registra as playlists de origem.
- Pesquisa por nome, grupo, ID e URL, com filtro para rádio ou TV.
- Biblioteca consolidada e favoritos persistidos no armazenamento local do navegador.
- Relatório de playlists lidas/falhas, canais únicos, duplicatas e disponibilidade pontual.
- Mantidos os limites de 100 entradas por playlist, 10 playlists por importação, 256 KiB por leitura, validação de destinos públicos e ausência de redirecionamento automático.

## 0.57.0 — Scanner de playlists e biblioteca de canais
- Leitura de metadados M3U `EXTINF` (nome, ID, logo, grupo e duração quando presentes).
- Resolução de URLs relativas com base no endereço da playlist.
- Classificação heurística de entradas como rádio, TV ou rádio/TV e identificação de formatos comuns pela URL e Content-Type.
- Verificação pontual de disponibilidade de até 100 entradas por playlist, com concorrência limitada a quatro consultas e sem seguir redirecionamentos.
- Favoritos guardados localmente no navegador, com filtro para exibir somente favoritos.
- A verificação de disponibilidade não garante reprodução contínua; status HTTP, CORS, codec e autenticação podem mudar.

## 0.56.0 — Reprodução HLS e MPEG-DASH
- Integração opcional no navegador com HLS.js para HLS em navegadores sem suporte nativo.
- Integração com DASH.js para reprodução de manifestos MPEG-DASH.
- Mantida reprodução nativa para streams diretos de áudio e vídeo.
- Libera tentativa de reprodução de playlists HLS/DASH sem declarar que a transmissão está garantidamente decodificável.
- Bibliotecas são carregadas por CDN; sem conexão ou se o CDN estiver bloqueado, HLS/DASH podem não reproduzir.

## 0.55.0 — Interface de análise e teste de reprodução
- Nova interface web em `/internet-media`, disponível somente para sessão autenticada como administrador.
- Formulário para enviar uma URL HTTP/HTTPS ao analisador existente em `/api/internet-media/inspect`.
- Exibição de tipo de mídia, formato, status HTTP, Content-Type, tamanho informado e endereços encontrados em playlists.
- Teste de reprodução direta com os elementos nativos de áudio/vídeo do navegador, quando o formato e o servidor forem compatíveis.
- A seleção de entradas de playlist preenche o campo para uma análise individual; não há varredura automática de canais nem reprodução garantida de HLS/DASH em todos os navegadores.
- Mantidos limite de 256 KiB, timeout de 8 segundos, bloqueio de destinos locais/privados e ausência de redirecionamento automático.

## Como usar
1. Inicie o FM-DX Webserver normalmente.
2. Entre no painel com uma conta de administrador.
3. Abra `/internet-media` no mesmo navegador/sessão.
4. Cole um link de rádio, TV ou playlist e toque em **Analisar link**.
5. Para uma playlist M3U/M3U8, toque em **Examinar playlist e canais** para extrair metadados e verificar disponibilidade.
6. Cadastre fontes autorizadas no **Guia pessoal**, filtre por país/categoria/formato e selecione até 10 para importar.
7. Use **Favoritar** para guardar canais neste navegador; **Analisar / reproduzir** abre a análise individual.

## Limitações e segurança
- A ferramenta analisa somente URLs informadas explicitamente pelo usuário; não captura tráfego de outros aplicativos.
- HTTPS protege o conteúdo em trânsito. Não há interceptação TLS, quebra de DRM, paywall, autenticação ou restrições de operadora.
- A identificação de HLS, DASH ou MPEG-TS não garante que o navegador consiga reproduzir o fluxo. DASH e HLS podem exigir bibliotecas/integrações específicas, codecs suportados e URLs/headers válidos.
- Playlists podem conter URLs relativas; a análise resolve entradas relativas para endereços absolutos, mas cada destino deve ser analisado separadamente.
- Endereços locais/privados são bloqueados para reduzir risco de SSRF. Redirecionamentos HTTP não são seguidos automaticamente.
- Não é um APK Android. O ZIP contém código-fonte; compilação e validação final devem ser feitas no ambiente Node.js/Android correspondente.

## Estrutura
- `android/`: aplicativo Android (Kotlin/Gradle).
- `fm-dx-webserver/`: servidor web Node.js, API e interface do analisador.
- `directory-service/`: serviço de diretório.

## Versões anteriores
A versão 0.54.0 introduziu a análise inicial de streams fornecidos pelo administrador, com identificação de MP3, AAC, OGG, Opus, HLS, MPEG-DASH, MPEG-TS e playlists M3U/M3U8. A versão 0.55.0 acrescenta interface web e tentativa de reprodução direta no navegador. A versão 0.56.0 adiciona HLS.js e DASH.js para tentar reproduzir HLS e MPEG-DASH. A versão 0.57.0 acrescenta scanner de playlists, metadados de canais, verificação pontual e favoritos locais. A versão 0.58.0 importa várias playlists, unifica canais, remove duplicados e oferece pesquisa/filtros com persistência local.

## Compilação e testes
Para o servidor: entre em `fm-dx-webserver/`, instale as dependências com `npm install` e execute `npm test`. Para o aplicativo Android, abra `android/` no Android Studio com JDK 17 e SDK compatível. A compilação Android completa precisa ser validada nesse ambiente.


## 0.59.0 — Monitoramento de disponibilidade

Permite revalidar até 100 canais da biblioteca, ativar atualização automática a cada 15 minutos enquanto a página estiver aberta e consultar um histórico local das últimas 20 verificações. A atualização não roda com a página fechada.


## FM-DX Universal 0.61.0 — Inteligência de Compatibilidade
A interface de rádio/TV oferece uma avaliação orientativa por formato (MP3, AAC, OGG, Opus, HLS, MPEG-DASH e MPEG-TS), sugere o mecanismo de reprodução e consulta `canPlayType` do navegador quando aplicável. Para HLS/DASH, indica a disponibilidade das bibliotecas do player. A avaliação não garante reprodução: codec real, CORS, autenticação, HTTPS, cabeçalhos e disponibilidade do servidor continuam determinantes. Nenhum DRM ou autenticação é contornado.


## FM-DX Universal 0.62.0 — Diagnóstico Inteligente de Reprodução

A versão 0.62.0 acrescenta diagnóstico orientativo de falhas em endereços de rádio/TV enviados pelo administrador. O diagnóstico diferencia redirecionamento, autenticação, recurso removido, limite de acesso, erro do servidor, timeout, falha de conexão, divergência de MIME e sinais de suporte do navegador. CORS e codecs podem impedir a reprodução mesmo quando o servidor responde HTTP 2xx; por isso, o resultado não é uma garantia. O recurso consulta somente a URL fornecida e não segue redirecionamentos, não procura fontes alternativas e não contorna autenticação, DRM ou paywall.


## Versão 0.63.0 — Central de Reprodução Universal

A interface Internet Media agora reúne reprodução de rádio e TV, fila local de até 100 canais, histórico dos últimos 30 canais e retomada do último canal selecionado. A persistência é local ao navegador; a reprodução depende do suporte do navegador e das permissões da fonte. Consulte `CHANGELOG-0.63.0.md`.


## Versão 0.64.0 — Fila Inteligente
Avanço automático ao fim da mídia, navegação anterior/próximo, estados de reprodução e recuperação segura de dados locais inválidos. Consulte `CHANGELOG-0.64.0.md`.


## Versão 0.65.0 — Reprodução Móvel Avançada
Controle de volume, temporizador de desligamento, reprodução contínua e interface responsiva para celulares. Consulte `CHANGELOG-0.65.0.md`.


## FM-DX Universal 0.66.0 — Media Session
A central de reprodução integra-se opcionalmente à API Media Session do navegador para disponibilizar metadados e ações de mídia (reproduzir, pausar, parar, próximo e anterior) em plataformas compatíveis. A disponibilidade depende do navegador e do sistema operacional. Isso não equivale a um serviço Android nativo de reprodução em primeiro plano: reprodução com o app encerrado ou em segundo plano não é garantida, especialmente no WebView e sob políticas de economia de bateria.

## Versão 0.67.0 — Serviço nativo de áudio em segundo plano

Adiciona um player Android nativo independente do WebView, com serviço em primeiro plano e notificação para pausar, retomar ou parar uma URL direta de áudio HTTP/HTTPS. Acesse **Áudio nativo em segundo plano** na tela inicial. O suporte a codecs e formatos depende do Android e do servidor; esta função não controla o player web, não garante HLS/DASH e não reproduz vídeo/TV em segundo plano. Consulte `CHANGELOG-0.67.0.md`.


## Versão 0.70.0 — Media3

O serviço nativo usa AndroidX Media3 ExoPlayer com módulos para HLS e MPEG-DASH, mantendo fila e controles de notificação. A disponibilidade efetiva depende do codec, da URL, do manifesto e do dispositivo. O projeto não remove DRM nem contorna autenticação.

### Versão 0.81.0 — robustez ARIB B24
Esta versão amplia os testes do decodificador parcial ARIB STD-B24 para GR/SS2, dados truncados e limites de entrada. A implementação continua conservadora e não equivale a um decodificador ARIB completo.

## Versão 0.82.0 — Guia EPG ISDB-T

Inclui uma grade de programação organizada por serviço, com horários convertidos de UTC para o fuso local, duração, título e sinopse. A tela permanece em estado de espera até que um backend ISDB-T forneça dados SI/EIT reais; não apresenta programação simulada como se fosse transmissão recebida. Consulte `CHANGELOG-0.82.0.md`.



## Versão 0.87.0 — Descoberta ampliada de SDR por diretórios

O catálogo SDR agora reúne portais comunitários adicionais para localizar servidores públicos (Global SDR Atlas, Live SDR Worldwide, Global SDR Hub e hams.live), além das fontes já cadastradas. A atualização renova o índice de portais, não executa uma varredura global da internet e não garante que cada receptor esteja online. Use a inspeção por URL para analisar individualmente um endereço SDR.

## Versão 0.88.0 — Pesquisa ampliada de servidores SDR públicos

Acrescenta atalhos de pesquisa para encontrar receptores públicos KiwiSDR, OpenWebRX, WebSDR, Web-888, SDR com VHF/UHF e SDR de HF/ondas curtas. As pesquisas abrem resultados externos em nova aba; não representam uma varredura automática de toda a internet nem uma confirmação de disponibilidade. Consulte `CHANGELOG-0.88.0.md`.


## Integração Android — Explorador SDR Mundial

A tela inicial do aplicativo Android inclui o cartão **Explorador SDR Mundial**. Ele apresenta atalhos para mapas e diretórios públicos (KiwiSDR, ReceiverBook/OpenWebRX, WebSDR.org, RX-TX.info, Web-888 e diretórios comunitários) e permite abrir uma URL SDR informada pelo usuário. A tela abre os diretórios no navegador e o receptor informado no WebView existente.

**Limite desta integração:** a tela Android não executa diretamente a análise automática da URL. O analisador remoto já documentado na versão 0.84.0 permanece no FM-DX Webserver, em `POST /api/internet-media/scan-sdr-url`; é necessário configurar e disponibilizar o servidor para usar esse endpoint. Os diretórios são fontes externas e não garantem disponibilidade, cobertura ou autorização de uso de cada receptor.


## 0.89.0 — Satélite FTA e IPTV

Consulte `CHANGELOG-0.89.0.md`. A interface Internet Radio & TV inclui cadastro local de parâmetros de transponders DVB-S/S2/S2X e indicação cautelosa de FTA em metadados M3U. O cadastro não realiza sintonia RF; recepção por satélite exige receptor compatível.
