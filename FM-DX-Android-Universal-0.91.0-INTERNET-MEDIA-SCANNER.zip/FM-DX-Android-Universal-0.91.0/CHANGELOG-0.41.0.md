# FM-DX Android Universal 0.41.0 — Community Evidence Exchange

## Novidades
- Exportação manual de relatório comunitário em JSON por meio do compartilhamento Android.
- Importação manual de JSON colado pelo usuário, com validação de formato, versão, tamanho e campos.
- Fingerprint exclusivo do firmware não é exportado; identificadores locais de observações importadas são sintéticos e derivados do conteúdo técnico.
- Observações importadas recebem origem `COMUNITÁRIO` e podem ser comparadas localmente com dados deste aparelho.
- Nenhum envio automático, serviço remoto, conta, número de série ou localização é utilizado.

## Privacidade e limites
- O compartilhamento é sempre iniciado pelo usuário e o conteúdo pode incluir fabricante, modelo, SoC, versão Android, categoria de resultado e dia do teste.
- O usuário deve revisar o JSON antes de compartilhá-lo. A anonimização reduz identificadores exclusivos, mas fabricante/modelo ainda podem identificar uma variante específica.
- Relatórios importados são observações fornecidas por terceiros, não evidência independente verificada. Não elevam o estado de compatibilidade FM.
- A importação aceita até 100 observações e 512 KB por pacote.

## Validação
- Inspeção do código alterado e validação estrutural do ZIP.
- Compilação Android completa e teste em aparelho real ainda precisam ser executados em Android Studio/Gradle com JDK 17 e SDK compatível.
