# FM-DX Android Universal 0.91.0

## INTERNET MEDIA SCANNER / TV BOX CONNECT

- Adicionada descoberta SSDP/UPnP (M-SEARCH) na rede Wi-Fi local, além da descoberta DNS-SD existente.
- Incluídos tipos DNS-SD `_upnp._tcp.` e `_dlna._tcp.`.
- Resultados SSDP mostram o endereço do dispositivo, serviço anunciado e URL `LOCATION` da descrição UPnP.
- Adicionado `CHANGE_WIFI_MULTICAST_STATE` e controle do `MulticastLock` durante a pesquisa.
- A pesquisa é limitada a descoberta anunciada em rede local: não faz varredura de portas, brute force, autenticação, bypass de DRM/HDCP ou captura de tráfego de outros aplicativos.
- A URL `LOCATION` é metadado de descrição do dispositivo; não é automaticamente uma URL de canal. A reprodução continua dependendo de uma URL de mídia autorizada fornecida pelo equipamento ou pelo usuário.
- Atualizado versionCode para 65 e versionName para 0.91.0.

## Verificação

Os testes Node do servidor devem ser executados em `fm-dx-webserver` com `npm test`. A compilação Android precisa ser executada em ambiente com Android SDK/Gradle configurados.
