# FM-DX Android Universal 0.59.0

## Monitoramento de disponibilidade e histórico

- Verificação manual de até 100 canais já presentes na biblioteca.
- Atualização automática opcional a cada 15 minutos enquanto a página estiver aberta e visível.
- Limite de quatro verificações simultâneas, timeout individual e validação de destinos públicos mantidos.
- Registro local das últimas 20 verificações, com data, quantidade consultada, canais ativos e indisponíveis.
- Cada canal passa a exibir a data da última verificação.
- A atualização automática não é executada em segundo plano quando a página está fechada.

## Segurança e limitações

- A API exige sessão de administrador autenticada.
- Apenas URLs já presentes na biblioteca são consultadas; não há descoberta indiscriminada de endereços.
- Limite de 100 canais por ciclo, sem seguir redirecionamentos nem contornar autenticação ou DRM.
- O histórico é local ao navegador/dispositivo e não sincroniza entre aparelhos.

## Testes

- Testes unitários e verificações de sintaxe executados na preparação da fonte.
- Não foi realizada compilação APK nem teste em hardware físico.
