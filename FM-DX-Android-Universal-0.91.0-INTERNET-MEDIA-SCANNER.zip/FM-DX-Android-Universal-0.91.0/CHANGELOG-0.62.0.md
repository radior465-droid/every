# FM-DX Android Universal 0.62.0 — Diagnóstico Inteligente de Reprodução

- Novo diagnóstico de uma URL HTTP/HTTPS explicitamente fornecida pelo administrador.
- Classifica respostas de redirecionamento, autenticação (401/403), recurso removido (404/410), limite de acesso (429), falhas 5xx, timeout e falhas de conexão/validação.
- Sinaliza divergência entre formato esperado e MIME retornado.
- Considera indicações locais do navegador, como `canPlayType` e disponibilidade de Media Source Extensions.
- Explicita que CORS pode impedir a reprodução e que HTTP 2xx não significa reprodução garantida.
- Adicionado botão **Diagnosticar falha** nos itens da biblioteca.
- Endpoint autenticado `POST /api/internet-media/diagnose`; consulta somente a URL enviada, sem seguir redirecionamentos ou procurar fontes alternativas.
- Mantidos os bloqueios de destinos privados, limites de tamanho/tempo e as proteções contra contorno de autenticação/DRM.
- Android atualizado para versionCode 39 / versionName 0.62.0.

O diagnóstico é heurístico. CORS, DRM, codecs internos e autenticação podem exigir confirmação no próprio navegador/provedor. Não houve compilação de APK nem teste em hardware físico nesta entrega.
