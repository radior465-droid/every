# FM-DX Android Universal 0.87.0 — Descoberta ampliada de diretórios SDR

## Novidades
- Catálogo SDR ampliado com portais comunitários de descoberta mundial.
- Incluídos Global SDR Atlas, Live SDR Worldwide (KC4MCQ), Global SDR Hub e hams.live.
- Versão do catálogo elevada para 2.
- Mensagem da interface esclarece que os portais ajudam a encontrar servidores, mas não equivalem a uma varredura de toda a internet nem garantem disponibilidade em tempo real.
- Mantida a inspeção individual de URL SDR já existente, com autenticação administrativa e validação de destino.

## Limitações
- Os novos itens são diretórios externos; o aplicativo abre o portal para pesquisa.
- A listagem de um servidor, suas faixas e seu estado podem mudar.
- Não foi implementado rastreamento indiscriminado da internet nem teste automático em massa de servidores de terceiros.
